/* Acorn Archimedes (A3000/A5000-style): ARM2 + MEMC1a + IOC + VIDC1a + WD1772 + CMOS + keyboard.
 * Portable C99, little-endian host. See README for status / known-guess areas. */
#include "arc.h"
#include <stdlib.h>
#include <string.h>

#define PCMASK 0x03FFFFFCu
#define LATCH_A_OFF 0x10u      /* GUESS: IOC bank 5 offset of floppy select latch (see README) */

static void upd_irq(Arc *a);
static uint32_t io_read(Arc *a, uint32_t ad);
static void io_write(Arc *a, uint32_t ad, uint32_t v);

/* ===================== bus / MEMC translation ===================== */
/* returns 0 = RAM/ROM pointer, 1 = I/O, -1 = abort */
static int xlate(Arc *a, uint32_t ad, int wr, uint8_t **p) {
    ad &= 0x03FFFFFFu;
    if (ad < 0x02000000u) {
        uint32_t sh, lpn; int e;
        if (!a->rom_high) { if (wr) return 1; *p = a->rom + (ad % a->rom_size); return 0; }
        sh = 12 + a->pagesize; lpn = ad >> sh; e = a->lpn_ppn[lpn];
        if (e < 0) return -1;
        if (a->mode == M_USR) { int ppl = a->ppn_ppl[e]; if (ppl == 0 || (wr && ppl == 1)) return -1; }
        *p = a->ram + ((((uint32_t)e << sh) | (ad & ((1u << sh) - 1))) % a->ram_size);
        return 0;
    }
    if (a->mode == M_USR) return -1;
    if (ad < 0x03000000u) { *p = a->ram + ((ad - 0x02000000u) % a->ram_size); return 0; }
    if (ad >= 0x03800000u && !wr) { a->rom_high = 1; *p = a->rom + ((ad - 0x03800000u) % a->rom_size); return 0; }
    return 1;
}
static uint32_t rd32(Arc *a, uint32_t ad) {
    uint8_t *p; int r = xlate(a, ad & ~3u, 0, &p); uint32_t v;
    if (r < 0) { a->abort = 1; return 0; }
    if (r == 0) { memcpy(&v, p, 4); return v; }
    return io_read(a, ad & ~3u);
}
static void wr32(Arc *a, uint32_t ad, uint32_t v) {
    uint8_t *p; int r = xlate(a, ad & ~3u, 1, &p);
    if (r < 0) { a->abort = 1; return; }
    if (r == 0) memcpy(p, &v, 4); else io_write(a, ad & ~3u, v);
}
static uint32_t rd8(Arc *a, uint32_t ad) {
    uint8_t *p; int r = xlate(a, ad, 0, &p);
    if (r < 0) { a->abort = 1; return 0; }
    return r == 0 ? *p : (io_read(a, ad & ~3u) & 0xFF);
}
static void wr8(Arc *a, uint32_t ad, uint32_t v) {
    uint8_t *p; int r = xlate(a, ad, 1, &p);
    if (r < 0) { a->abort = 1; return; }
    if (r == 0) *p = (uint8_t)v; else io_write(a, ad & ~3u, v & 0xFF);
}

static void memc_map(Arc *a, uint32_t ad) {      /* write into 0x3800000.. : page-table entry */
    uint32_t ppn, lpn, ppl = (ad >> 8) & 3;
    switch (a->pagesize) {
    case 0:  ppn = ad & 0x7F;                         lpn = ((ad >> 12) & 0x7FF) | ((ad & 0xC00) << 1); break;
    case 1:  ppn = ((ad >> 1) & 0x3F) | ((ad & 1) << 6); lpn = ((ad >> 13) & 0x3FF) | (ad & 0xC00); break;
    case 2:  ppn = ((ad >> 2) & 0x1F) | ((ad & 3) << 5); lpn = ((ad >> 14) & 0x1FF) | ((ad & 0xC00) >> 1); break;
    default: ppn = ((ad >> 3) & 0x0F) | ((ad & 7) << 4); lpn = ((ad >> 15) & 0xFF) | ((ad & 0xC00) >> 2); break;
    }
    if (lpn >= 8192) return;
    if (a->ppn_lpn[ppn] >= 0) a->lpn_ppn[a->ppn_lpn[ppn]] = -1;
    if (a->lpn_ppn[lpn] >= 0) a->ppn_lpn[a->lpn_ppn[lpn]] = -1;
    a->lpn_ppn[lpn] = (int16_t)ppn; a->ppn_lpn[ppn] = (int16_t)lpn; a->ppn_ppl[ppn] = (uint8_t)ppl;
}
static void snd_try_start(Arc *a) {
    if (a->sdma && !a->s_running && a->s_valid) {
        a->s_cur = a->s_nstart; a->s_end = a->s_nend; a->s_valid = 0; a->s_running = 1; a->snd_irq = 1;   /* ask OS for the next buffer */
    }
}
static void memc_reg(Arc *a, uint32_t ad) {      /* write into 0x3600000.. */
    uint32_t dma = ((ad >> 2) & 0x7FFF) << 4;
    switch ((ad >> 17) & 7) {
    case 0: a->vinit = dma; break;
    case 1: a->vstart = dma; break;
    case 2: a->vend = dma; break;
    case 3: a->cinit = dma; break;
    case 7: {
        int ps = (ad >> 2) & 3;
        if (ps != a->pagesize) { a->pagesize = ps; memset(a->lpn_ppn, 0xFF, sizeof a->lpn_ppn); memset(a->ppn_lpn, 0xFF, sizeof a->ppn_lpn); }
        a->vdma = (ad >> 10) & 1;
        a->sdma = (ad >> 11) & 1;
        if (!a->sdma) a->s_running = 0; else snd_try_start(a);
        break; }
    case 4: a->s_nstart = dma; break;                                   /* Sstart */
    case 5: a->s_nend = dma; a->s_valid = 1; a->snd_irq = 0; snd_try_start(a); break;   /* SendN */
    default: break;                              /* Sptr: ignored */
    }
    upd_irq(a);
}

/* ===================== VIDC ===================== */
static void vidc_write(Arc *a, uint32_t v) {
    uint32_t sel = v >> 24;
    if (sel < 0x40) a->pal[sel >> 2] = v & 0x1FFF;
    else if (sel >= 0x44 && sel <= 0x4C) a->cpal[((sel - 0x44) >> 2) + 1] = v & 0x1FFF;
    else if (sel >= 0x80 && sel <= 0xBC) {
        int i = (sel - 0x80) >> 2;
        a->vreg[i] = (i == 6) ? ((v >> 13) & 0x7FF) : ((v >> 14) & 0x3FF);
    } else if (sel >= 0x60 && sel <= 0x7C) a->sbal[(sel - 0x60) >> 2] = v & 7;
    else if (sel == 0xC0) a->vfreq = v & 0xFF;
    else if (sel == 0xE0) a->vctl = v & 0xFFFF;
}
void arc_video_size(const Arc *a, int *w, int *h) {
    static const int snap[] = { 320, 640, 800, 1024 };
    int hh = (int)a->vreg[12] - (int)a->vreg[11], ww = ((int)a->vreg[4] - (int)a->vreg[3]) * 2, i, best = 640;
    if (hh < 32 || hh > ARC_MAX_H) hh = 256;
    if (ww < 64) ww = 640;
    for (i = 0; i < 4; i++) if (abs(snap[i] - ww) < abs(best - ww)) best = snap[i];
    *w = best; *h = hh;
}
static uint32_t rgb13(uint16_t c) {
    return 0xFF000000u | (((c & 15) * 17u) << 16) | ((((c >> 4) & 15) * 17u) << 8) | (((c >> 8) & 15) * 17u);
}
void arc_render(const Arc *a, uint32_t *out, int w, int h) {
    int bpp = 1 << ((a->vctl >> 2) & 3), x, y, n = 1 << bpp; uint32_t lut[256], stride = (uint32_t)w * bpp / 8, mask = (uint32_t)n - 1;
    if (!a->vdma) { for (x = 0; x < w * h; x++) out[x] = 0xFF000000u; return; }
    for (x = 0; x < n; x++) {
        if (bpp == 8) {
            uint16_t p = a->pal[x & 15];
            unsigned r = (p & 7) | ((x >> 1) & 8), g = ((p >> 4) & 3) | ((x >> 3) & 12), b = ((p >> 8) & 7) | ((x >> 4) & 8);
            lut[x] = 0xFF000000u | (r * 17u << 16) | (g * 17u << 8) | (b * 17u);
        } else lut[x] = rgb13(a->pal[x & 15]);
    }
    for (y = 0; y < h; y++)
        for (x = 0; x < w; x++) {
            uint32_t bit = (uint32_t)x * bpp, off = a->vinit + (uint32_t)y * stride + (bit >> 3);
            out[y * w + x] = lut[(a->ram[off % a->ram_size] >> (bit & 7)) & mask];
        }
    {   /* hardware pointer (position is approximate: see README) */
        int cx = (int)a->vreg[6] - (int)a->vreg[3] * 2, cy = (int)a->vreg[14] - (int)a->vreg[11], ch = (int)a->vreg[15] - (int)a->vreg[14], i, j;
        if (ch > 64) ch = 64;
        for (j = 0; j < ch; j++)
            for (i = 0; i < 32; i++) {
                uint32_t b = a->ram[(a->cinit + j * 8 + (i >> 2)) % a->ram_size]; int c = (b >> ((i & 3) * 2)) & 3;
                int px = cx + i, py = cy + j;
                if (c && px >= 0 && px < w && py >= 0 && py < h) out[py * w + px] = rgb13(a->cpal[c]);
            }
    }
}

/* ===================== I2C CMOS (PCF8583) ===================== */
static void i2c_byte(Arc *a) {
    uint8_t b = a->i2c_shift; a->i2c_ackout = 1; a->i2c_next = a->i2c_mode;
    switch (a->i2c_mode) {
    case 1: if ((b & 0xFE) == 0xA0) a->i2c_next = (b & 1) ? 4 : 2; else { a->i2c_ackout = 0; a->i2c_next = 0; } break;
    case 2: a->i2c_ptr = b; a->i2c_next = 3; break;
    case 3: a->cmos[a->i2c_ptr++] = b; break;
    }
}
static void i2c_rise(Arc *a) {
    if (a->i2c_mode == 0) return;
    if (a->i2c_nbit < 8) {
        if (a->i2c_mode == 4) { a->i2c_nbit++; return; }
        a->i2c_shift = (uint8_t)((a->i2c_shift << 1) | a->i2c_sdam); a->i2c_nbit++;
        if (a->i2c_nbit == 8) i2c_byte(a);
    } else if (a->i2c_nbit == 8) { if (a->i2c_mode == 4) a->i2c_ack = !a->i2c_sdam; a->i2c_nbit = 9; }
}
static void i2c_fall(Arc *a) {
    if (a->i2c_mode == 0) return;
    if (a->i2c_nbit == 8) { a->i2c_sdas = (a->i2c_mode == 4) ? 1 : (a->i2c_ackout ? 0 : 1); return; }
    if (a->i2c_nbit == 9) {
        a->i2c_sdas = 1; a->i2c_nbit = 0;
        if (a->i2c_mode == 4) {
            if (a->i2c_ack) { a->i2c_ptr++; a->i2c_tx = a->cmos[a->i2c_ptr]; a->i2c_sdas = a->i2c_tx >> 7; } else a->i2c_mode = 0;
        } else {
            a->i2c_mode = a->i2c_next;
            if (a->i2c_mode == 4) { a->i2c_tx = a->cmos[a->i2c_ptr]; a->i2c_sdas = a->i2c_tx >> 7; }
        }
        return;
    }
    if (a->i2c_mode == 4 && a->i2c_nbit >= 1) a->i2c_sdas = (a->i2c_tx >> (7 - a->i2c_nbit)) & 1;
}
static void i2c_update(Arc *a, int scl, int sda) {
    int oscl = a->i2c_scl, osda = a->i2c_sdam & a->i2c_sdas, nsda;
    a->i2c_scl = scl; a->i2c_sdam = sda; nsda = a->i2c_sdam & a->i2c_sdas;
    if (scl && oscl) {
        if (osda && !nsda) { a->i2c_mode = 1; a->i2c_nbit = 0; a->i2c_shift = 0; a->i2c_sdas = 1; return; }
        if (!osda && nsda) { a->i2c_mode = 0; a->i2c_sdas = 1; return; }
    }
    if (scl && !oscl) i2c_rise(a); else if (!scl && oscl) i2c_fall(a);
}

/* ===================== keyboard / mouse ===================== */
static void kb_deliver(Arc *a) {
    if (a->kb_state < 3 || a->kart_full || a->kb_wait) return;
    if (a->kq_n == 0 && (a->mdx || a->mdy)) {
        int x = a->mdx > 63 ? 63 : a->mdx < -63 ? -63 : a->mdx, y = -a->mdy; y = y > 63 ? 63 : y < -63 ? -63 : y;
        a->mdx = a->mdy = 0; a->kq[0] = (uint8_t)(x & 0x7F); a->kq[1] = (uint8_t)(y & 0x7F); a->kq_h = 0; a->kq_n = 2;
    }
    if (a->kq_n == 0) return;
    a->kart_rx = a->kq[a->kq_h]; a->kq_h = (a->kq_h + 1) & 63; a->kq_n--;
    a->kart_full = 1; a->kb_wait = 1; upd_irq(a);
}
static void kb_reply(Arc *a, uint8_t b) { a->kart_rx = b; a->kart_full = 1; upd_irq(a); }
static void kb_tx(Arc *a, uint8_t b) {
    switch (b) {
    case 0xFF: a->kb_state = 1; a->kq_n = 0; kb_reply(a, 0xFF); break;           /* HRST */
    case 0xFE: a->kb_state = 2; kb_reply(a, 0xFE); break;                         /* RAK1 */
    case 0xFD: a->kb_state = 3; a->kb_wait = 0; kb_reply(a, 0xFD); break;         /* RAK2 */
    case 0x20: kb_reply(a, 0x81); break;                                          /* RQID: UK keyboard */
    case 0x30: case 0x31: case 0x32: case 0x33: case 0x3F: case 0x40:            /* acks / RQPD */
        a->kb_wait = 0; kb_deliver(a); break;
    default: break;                                                               /* LED bytes etc. */
    }
}
static void kb_push(Arc *a, uint8_t b) { if (a->kq_n < 64) a->kq[(a->kq_h + a->kq_n++) & 63] = b; }
void arc_key(Arc *a, int k, int down) {
    uint8_t base = down ? 0xC0 : 0xD0;
    kb_push(a, base | (uint8_t)((k >> 4) & 15)); kb_push(a, base | (uint8_t)(k & 15)); kb_deliver(a);
}
void arc_mouse_move(Arc *a, int dx, int dy) { a->mdx += dx; a->mdy += dy; kb_deliver(a); }

/* ===================== WD1772 floppy ===================== */
static int cur_drive(const Arc *a) {
    int i; if (!a->latch_set) return 0;
    for (i = 0; i < ARC_NDRIVES; i++) if (!((a->latch_a >> i) & 1)) return i;
    return -1;
}
static int sector_off(const Floppy *f, int trk, int side, int sec) {
    if (!f->inserted || trk < 0 || trk >= f->tracks || side < 0 || side >= f->sides) return -1;
    sec -= f->first; if (sec < 0 || sec >= f->spt) return -1;
    return ((trk * f->sides + side) * f->spt + sec) * (int)f->ssize;
}
static void fdc_load_sector(Arc *a, int write) {
    int d = cur_drive(a), off = -1, side = (a->latch_a & 0x10) ? 0 : 1; Floppy *f = d >= 0 ? &a->fdd[d] : NULL;
    if (f) { if (f->sides == 1) side = 0; off = sector_off(f, a->head_track[d], side, a->fdc_sector); }
    if (off < 0) { a->fdc_state = 0; a->fdc_status = 0x10; a->fdc_drq = 0; a->fdc_irq = 1; return; }
    a->fdc_drive = d; a->fdc_off = off; a->fdc_len = f->ssize; a->fdc_pos = 0; a->fdd_activity = 30;
    if (write) { a->fdc_state = 2; a->fdc_status = 0x03; }
    else { memcpy(a->fdc_buf, f->data + off, f->ssize); a->fdc_state = 1; a->fdc_status = 0x03; }
    a->fdc_drq = 1;
}
static void fdc_cmd(Arc *a, uint8_t c) {
    int d = cur_drive(a); Floppy *f = d >= 0 ? &a->fdd[d] : NULL;
    a->fdc_irq = 0;
    if ((c & 0xF0) == 0xD0) {                               /* force interrupt */
        a->fdc_state = 0; a->fdc_drq = 0; a->fdc_status &= ~3; if (c & 0x0F) a->fdc_irq = 1; upd_irq(a); return;
    }
    a->fdc_multi = (c >> 4) & 1;
    if (c < 0x80) {                                         /* type I */
        int up = c & 0x10;
        a->fdc_type1 = 1; a->fdc_hl = (c & 8) ? 0x20 : 0; a->fdc_state = 0;
        if (d >= 0) {
            int *ht = &a->head_track[d];
            switch (c >> 5) {
            case 0: if ((c & 0xE0) == 0 && !(c & 0x10)) { *ht = 0; a->fdc_track = 0; }           /* restore */
                    else { *ht = a->fdc_data; a->fdc_track = a->fdc_data; } break;                /* seek */
            case 1: *ht += a->fdc_dir; if (up) a->fdc_track += a->fdc_dir; break;                 /* step */
            case 2: a->fdc_dir = 1;  *ht += 1; if (up) a->fdc_track++; break;                     /* step in */
            default: a->fdc_dir = -1; if (*ht > 0) (*ht)--; if (up) a->fdc_track--; break;        /* step out */
            }
            if (*ht < 0) *ht = 0; if (*ht > 85) *ht = 85;
        }
        a->fdc_irq = 1; a->fdc_drq = 0; upd_irq(a); return;
    }
    a->fdc_type1 = 0;
    if (!f || !f->inserted) { a->fdc_status = 0x80; a->fdc_irq = 1; upd_irq(a); return; }
    switch (c >> 4) {
    case 0x8: case 0x9: fdc_load_sector(a, 0); break;
    case 0xA: case 0xB:
        if (f->protect || !f->writable) { a->fdc_status = 0x40; a->fdc_irq = 1; } else fdc_load_sector(a, 1);
        break;
    case 0xC: {                                             /* read address */
        a->fdc_buf[0] = (uint8_t)a->head_track[d]; a->fdc_buf[1] = (a->latch_a & 0x10) ? 0 : (f->sides > 1);
        a->fdc_buf[2] = (uint8_t)f->first; a->fdc_buf[3] = (uint8_t)(f->ssize == 256 ? 1 : f->ssize == 512 ? 2 : 3);
        a->fdc_buf[4] = a->fdc_buf[5] = 0; a->fdc_len = 6; a->fdc_pos = 0; a->fdc_state = 3; a->fdc_status = 0x03; a->fdc_drq = 1;
        break; }
    default: a->fdc_status = 0x10; a->fdc_irq = 1; break;  /* read/write track: unsupported */
    }
    upd_irq(a);
}
static uint32_t fdc_read(Arc *a, int reg) {
    uint32_t v = 0;
    switch (reg) {
    case 0:
        v = a->fdc_status;
        if (a->fdc_state == 0 && a->fdc_type1) {
            int d = cur_drive(a); Floppy *f = d >= 0 ? &a->fdd[d] : NULL;
            v = a->fdc_hl | ((d >= 0 && a->head_track[d] == 0) ? 4 : 0);
            if (!f || !f->inserted) v |= 0x80;
            else { if (f->protect || !f->writable) v |= 0x40; if ((a->cycles % 1600000u) < 32000u) v |= 2; }
        }
        a->fdc_irq = 0; upd_irq(a); break;
    case 1: v = (uint32_t)a->fdc_track & 0xFF; break;
    case 2: v = (uint32_t)a->fdc_sector & 0xFF; break;
    default:
        v = a->fdc_data;
        if ((a->fdc_state == 1 || a->fdc_state == 3) && a->fdc_drq) {
            v = a->fdc_buf[a->fdc_pos++]; a->fdc_data = (int)v;
            if (a->fdc_pos >= a->fdc_len) {
                if (a->fdc_state == 1 && a->fdc_multi) { a->fdc_sector++; fdc_load_sector(a, 0); }
                else { a->fdc_state = 0; a->fdc_drq = 0; a->fdc_status &= ~3; a->fdc_irq = 1; }
                upd_irq(a);
            }
        }
        break;
    }
    return v;
}
static void fdc_write(Arc *a, int reg, uint8_t v) {
    switch (reg) {
    case 0: fdc_cmd(a, v); break;
    case 1: a->fdc_track = v; break;
    case 2: a->fdc_sector = v; break;
    default:
        a->fdc_data = v;
        if (a->fdc_state == 2 && a->fdc_drq) {
            a->fdc_buf[a->fdc_pos++] = v;
            if (a->fdc_pos >= a->fdc_len) {
                Floppy *f = &a->fdd[a->fdc_drive];
                memcpy(f->data + a->fdc_off, a->fdc_buf, a->fdc_len);
                if (f->fp) { fseek(f->fp, a->fdc_off, SEEK_SET); fwrite(a->fdc_buf, 1, a->fdc_len, f->fp); fflush(f->fp); }
                a->fdc_state = 0; a->fdc_drq = 0; a->fdc_status &= ~3; a->fdc_irq = 1; upd_irq(a);
            }
        }
        break;
    }
}

/* ===================== IOC ===================== */
static uint8_t irqb_status(const Arc *a) { return (a->fdc_irq ? 0x10 : 0) | (a->snd_irq ? 0x02 : 0) | 0x40 | (a->kart_full ? 0x80 : 0); }
static void upd_irq(Arc *a) {
    a->irq = ((((a->irqA_edge | 0x80) & a->irqA_mask) | (irqb_status(a) & a->irqB_mask)) != 0);
    a->fiq = (((0x80 | (a->fdc_drq ? 1 : 0) | (a->fdc_irq ? 2 : 0)) & a->fiq_mask) != 0);
}
static void unknown_io(Arc *a, uint32_t ad, int wr, uint32_t v) {
    a->unk_count++; a->unk_last = ad;
    if (a->trace && a->unk_count < 200) fprintf(stderr, "[io] unmapped %s %08x %08x (pc=%07x)\n", wr ? "write" : "read ", ad, v, a->pc);
}
static uint32_t ioc_read(Arc *a, uint32_t ad) {
    int r = (ad >> 2) & 0x1F;
    switch (r) {
    case 0x00: return 0xFC | ((a->i2c_sdam & a->i2c_sdas) << 1) | (a->i2c_scl & 1);
    case 0x01: { uint32_t v = a->kart_rx; a->kart_full = 0; upd_irq(a); kb_deliver(a); return v; }
    case 0x04: return a->irqA_edge | 0x80;
    case 0x05: return (a->irqA_edge | 0x80) & a->irqA_mask;
    case 0x06: return a->irqA_mask;
    case 0x08: return irqb_status(a);
    case 0x09: return irqb_status(a) & a->irqB_mask;
    case 0x0A: return a->irqB_mask;
    case 0x0C: return 0x80 | (a->fdc_drq ? 1 : 0) | (a->fdc_irq ? 2 : 0);
    case 0x0D: return (0x80 | (a->fdc_drq ? 1 : 0) | (a->fdc_irq ? 2 : 0)) & a->fiq_mask;
    case 0x0E: return a->fiq_mask;
    default:
        if (r >= 0x10 && r < 0x20) { int t = (r - 0x10) >> 2, s = (r - 0x10) & 3;
            if (s == 0) return a->t_out[t] & 0xFF; if (s == 1) return a->t_out[t] >> 8; return 0; }
        unknown_io(a, ad, 0, 0); return 0;
    }
}
static void ioc_write(Arc *a, uint32_t ad, uint32_t v) {
    int r = (ad >> 2) & 0x1F; v &= 0xFF;
    switch (r) {
    case 0x00: i2c_update(a, v & 1, (v >> 1) & 1); break;
    case 0x01: kb_tx(a, (uint8_t)v); break;
    case 0x05: a->irqA_edge &= (uint8_t)~v; upd_irq(a); break;
    case 0x06: a->irqA_mask = (uint8_t)v; upd_irq(a); break;
    case 0x0A: a->irqB_mask = (uint8_t)v; upd_irq(a); break;
    case 0x0E: a->fiq_mask = (uint8_t)v; upd_irq(a); break;
    default:
        if (r >= 0x10 && r < 0x20) { int t = (r - 0x10) >> 2, s = (r - 0x10) & 3;
            if (s == 0) a->t_latch[t] = (uint16_t)((a->t_latch[t] & 0xFF00) | v);
            else if (s == 1) a->t_latch[t] = (uint16_t)((a->t_latch[t] & 0x00FF) | (v << 8));
            else if (s == 2) a->t_count[t] = a->t_latch[t];
            else a->t_out[t] = (uint16_t)a->t_count[t];
            break; }
        unknown_io(a, ad, 1, v);
    }
}
static uint32_t io_read(Arc *a, uint32_t ad) {
    if ((ad & 0xFFFF0000u) == 0x03200000u) return ioc_read(a, ad);
    if ((ad & 0xFFFF0000u) == 0x03310000u) return fdc_read(a, (ad >> 2) & 3);
    if (ad < 0x03000000u || ad >= 0x03400000u) return 0;
    unknown_io(a, ad, 0, 0); return 0xFFFFFFFFu;     /* floating bus: no expansion cards */
}
static void io_write(Arc *a, uint32_t ad, uint32_t v) {
    if (ad < 0x03000000u) return;
    if ((ad & 0xFFFF0000u) == 0x03200000u) ioc_write(a, ad, v);
    else if ((ad & 0xFFFF0000u) == 0x03310000u) fdc_write(a, (ad >> 2) & 3, (uint8_t)v);
    else if ((ad & 0xFFFF0000u) == 0x03350000u) { if ((ad & 0x1F) == LATCH_A_OFF) { a->latch_a = (uint8_t)v; a->latch_set = 1; } }
    else if (ad >= 0x03800000u) memc_map(a, ad);
    else if (ad >= 0x03600000u) memc_reg(a, ad);
    else if (ad >= 0x03400000u) vidc_write(a, v);
    else unknown_io(a, ad, 1, v);
}

static void hw_tick(Arc *a, uint32_t cycles) {
    uint32_t ticks, t; a->t_acc += cycles; ticks = a->t_acc >> 2; a->t_acc &= 3;
    for (t = 0; t < 4; t++) {
        int32_t c = a->t_count[t] - (int32_t)ticks;
        if (c < 0) {
            uint32_t per = (uint32_t)a->t_latch[t] + 1, k = ((uint32_t)(-c) + per - 1) / per;
            c += (int32_t)(k * per);
            if (t == 0) a->irqA_edge |= 0x20; else if (t == 1) a->irqA_edge |= 0x40;
        }
        a->t_count[t] = c;
    }
    upd_irq(a);
}

/* ===================== ARM2 core ===================== */
static uint32_t psr_word(const Arc *a, uint32_t pc) {
    return (pc & PCMASK) | ((uint32_t)a->N << 31) | ((uint32_t)a->Z << 30) | ((uint32_t)a->C << 29) |
           ((uint32_t)a->V << 28) | ((uint32_t)a->I << 27) | ((uint32_t)a->F << 26) | (uint32_t)a->mode;
}
static uint32_t getr(const Arc *a, int n, int ext) { return n == 15 ? psr_word(a, a->pc + 8 + (ext ? 4 : 0)) : a->r[n]; }
static void set_mode(Arc *a, int m) {
    int old = a->mode, i; if (m == old) return;
    if (old == M_FIQ) for (i = 0; i < 7; i++) a->bank[M_FIQ][i] = a->r[8 + i];
    else { for (i = 0; i < 5; i++) a->shared[i] = a->r[8 + i]; a->bank[old][5] = a->r[13]; a->bank[old][6] = a->r[14]; }
    if (m == M_FIQ) for (i = 0; i < 7; i++) a->r[8 + i] = a->bank[M_FIQ][i];
    else { for (i = 0; i < 5; i++) a->r[8 + i] = a->shared[i]; a->r[13] = a->bank[m][5]; a->r[14] = a->bank[m][6]; }
    a->mode = m;
}
static void set_psr(Arc *a, uint32_t v) {
    a->N = v >> 31 & 1; a->Z = v >> 30 & 1; a->C = v >> 29 & 1; a->V = v >> 28 & 1;
    if (a->mode != M_USR) { a->I = v >> 27 & 1; a->F = v >> 26 & 1; set_mode(a, v & 3); }
}
static void exception(Arc *a, uint32_t vec, int mode, uint32_t retoff) {
    uint32_t lr = psr_word(a, a->pc + retoff);
    set_mode(a, mode); a->r[14] = lr; a->I = 1; if (mode == M_FIQ) a->F = 1; a->npc = vec;
}
static uint32_t shiftop(int type, uint32_t v, uint32_t n, int imm, int *c) {
    switch (type) {
    case 0: if (n == 0) return v; if (n < 32) { *c = (v >> (32 - n)) & 1; return v << n; } if (n == 32) { *c = v & 1; return 0; } *c = 0; return 0;
    case 1: if (imm && n == 0) n = 32; if (n == 0) return v;
            if (n < 32) { *c = (v >> (n - 1)) & 1; return v >> n; } if (n == 32) { *c = v >> 31; return 0; } *c = 0; return 0;
    case 2: if (imm && n == 0) n = 32; if (n == 0) return v;
            if (n < 32) { *c = (v >> (n - 1)) & 1; return (uint32_t)((int32_t)v >> n); } *c = v >> 31; return (uint32_t)((int32_t)v >> 31);
    default: if (imm && n == 0) { uint32_t r = ((uint32_t)*c << 31) | (v >> 1); *c = v & 1; return r; }
            if (n == 0) return v; n &= 31; if (n == 0) { *c = v >> 31; return v; }
            *c = (v >> (n - 1)) & 1; return (v >> n) | (v << (32 - n));
    }
}
static void setnz(Arc *a, uint32_t r) { a->N = r >> 31; a->Z = (r == 0); }

static void dataproc(Arc *a, uint32_t i) {
    int op = (i >> 21) & 15, s = (i >> 20) & 1, rn = (i >> 16) & 15, rd = (i >> 12) & 15, c = a->C, v = a->V, logical = 0;
    uint32_t op2, rnv, res = 0; uint64_t t;
    if (i & (1u << 25)) {
        uint32_t rot = ((i >> 8) & 15) * 2; op2 = i & 255;
        if (rot) { op2 = (op2 >> rot) | (op2 << (32 - rot)); c = op2 >> 31; }
        rnv = getr(a, rn, 0);
    } else {
        int byreg = (i >> 4) & 1; uint32_t n, val = getr(a, i & 15, byreg);
        n = byreg ? (getr(a, (i >> 8) & 15, 1) & 255) : ((i >> 7) & 31);
        op2 = shiftop((i >> 5) & 3, val, n, !byreg, &c); rnv = getr(a, rn, byreg);
    }
    switch (op) {
    case 0: case 8:  res = rnv & op2; logical = 1; break;
    case 1: case 9:  res = rnv ^ op2; logical = 1; break;
    case 2: case 10: t = (uint64_t)rnv + (uint32_t)~op2 + 1; res = (uint32_t)t; c = t >> 32; v = ((rnv ^ op2) & (rnv ^ res)) >> 31; break;
    case 3:          t = (uint64_t)op2 + (uint32_t)~rnv + 1; res = (uint32_t)t; c = t >> 32; v = ((op2 ^ rnv) & (op2 ^ res)) >> 31; break;
    case 4: case 11: t = (uint64_t)rnv + op2; res = (uint32_t)t; c = t >> 32; v = (~(rnv ^ op2) & (rnv ^ res)) >> 31; break;
    case 5:          t = (uint64_t)rnv + op2 + a->C; res = (uint32_t)t; c = t >> 32; v = (~(rnv ^ op2) & (rnv ^ res)) >> 31; break;
    case 6:          t = (uint64_t)rnv + (uint32_t)~op2 + a->C; res = (uint32_t)t; c = t >> 32; v = ((rnv ^ op2) & (rnv ^ res)) >> 31; break;
    case 7:          t = (uint64_t)op2 + (uint32_t)~rnv + a->C; res = (uint32_t)t; c = t >> 32; v = ((op2 ^ rnv) & (op2 ^ res)) >> 31; break;
    case 12: res = rnv | op2; logical = 1; break;
    case 13: res = op2; logical = 1; break;
    case 14: res = rnv & ~op2; logical = 1; break;
    default: res = ~op2; logical = 1; break;
    }
    if (op >= 8 && op <= 11) {
        if (!s) return;
        if (rd == 15) { set_psr(a, res); return; }
        setnz(a, res); a->C = c; a->V = v; return;
    }
    if (rd == 15) { if (s) set_psr(a, res); a->npc = res & PCMASK; return; }
    a->r[rd] = res;
    if (s) { setnz(a, res); a->C = c; if (!logical) a->V = v; }
}
static void ldst(Arc *a, uint32_t i) {
    int rn = (i >> 16) & 15, rd = (i >> 12) & 15, P = i >> 24 & 1, U = i >> 23 & 1, B = i >> 22 & 1, W = i >> 21 & 1, L = i >> 20 & 1, c = a->C;
    uint32_t off, base, addr, ea, val;
    off = (i & (1u << 25)) ? shiftop((i >> 5) & 3, getr(a, i & 15, 0), (i >> 7) & 31, 1, &c) : (i & 0xFFF);
    base = rn == 15 ? ((a->pc + 8) & PCMASK) : a->r[rn];
    addr = U ? base + off : base - off; ea = P ? addr : base;
    if (L) {
        if (B) val = rd8(a, ea);
        else { uint32_t w = rd32(a, ea), rot = (ea & 3) * 8; val = rot ? (w >> rot) | (w << (32 - rot)) : w; }
        if (a->abort) return;
        if ((!P || W) && rn != 15) a->r[rn] = addr;
        if (rd == 15) a->npc = val & PCMASK; else a->r[rd] = val;
    } else {
        val = rd == 15 ? psr_word(a, a->pc + 12) : a->r[rd];
        if (B) wr8(a, ea, val); else wr32(a, ea, val);
        if (a->abort) return;
        if ((!P || W) && rn != 15) a->r[rn] = addr;
    }
}
static void ldm_stm(Arc *a, uint32_t i) {
    int rn = (i >> 16) & 15, P = i >> 24 & 1, U = i >> 23 & 1, S = i >> 22 & 1, W = i >> 21 & 1, L = i >> 20 & 1, k, n = 0, usr, old = a->mode;
    uint32_t list = i & 0xFFFF, base = a->r[rn], ad;
    for (k = 0; k < 16; k++) n += (list >> k) & 1;
    ad = U ? (P ? base + 4 : base) : (P ? base - 4 * n : base - 4 * n + 4);
    if (W) a->r[rn] = U ? base + 4 * n : base - 4 * n;
    usr = S && !(L && (list & 0x8000));
    if (usr) set_mode(a, M_USR);
    for (k = 0; k < 16 && !a->abort; k++) {
        if (!((list >> k) & 1)) continue;
        if (L) { uint32_t v = rd32(a, ad); if (a->abort) break;
                 if (k == 15) { if (S) set_psr(a, v); a->npc = v & PCMASK; } else a->r[k] = v; }
        else wr32(a, ad, k == 15 ? psr_word(a, a->pc + 12) : a->r[k]);
        ad += 4;
    }
    if (usr) set_mode(a, old);
    if (a->abort && W) a->r[rn] = base;
}
static int cond_ok(const Arc *a, int cc) {
    switch (cc) {
    case 0: return a->Z; case 1: return !a->Z; case 2: return a->C; case 3: return !a->C;
    case 4: return a->N; case 5: return !a->N; case 6: return a->V; case 7: return !a->V;
    case 8: return a->C && !a->Z; case 9: return !a->C || a->Z; case 10: return a->N == a->V; case 11: return a->N != a->V;
    case 12: return !a->Z && a->N == a->V; case 13: return a->Z || a->N != a->V; case 14: return 1; default: return 0;
    }
}
static void step(Arc *a) {
    uint32_t i = 0; uint8_t *p; int r;
    if (a->fiq && !a->F) { exception(a, 0x1C, M_FIQ, 4); a->pc = a->npc; return; }
    if (a->irq && !a->I) { exception(a, 0x18, M_IRQ, 4); a->pc = a->npc; return; }
    r = xlate(a, a->pc, 0, &p);
    if (r < 0) { exception(a, 0x0C, M_SVC, 4); a->pc = a->npc; return; }
    if (r == 0) memcpy(&i, p, 4);
    a->npc = (a->pc + 4) & PCMASK;
    if (cond_ok(a, i >> 28)) {
        switch ((i >> 26) & 3) {
        case 0:
            if ((i & 0x0FC000F0) == 0x00000090) {
                int rd = (i >> 16) & 15, rn = (i >> 12) & 15, rs = (i >> 8) & 15, rm = i & 15;
                uint32_t res = a->r[rm] * a->r[rs] + ((i & (1u << 21)) ? a->r[rn] : 0);
                if (rd != 15) a->r[rd] = res;
                if (i & (1u << 20)) setnz(a, res);
            } else dataproc(a, i);
            break;
        case 1: ldst(a, i); break;
        case 2:
            if (i & (1u << 25)) {
                int32_t off = ((int32_t)(i << 8)) >> 6;
                if (i & (1u << 24)) a->r[14] = psr_word(a, a->pc + 4);
                a->npc = (a->pc + 8 + off) & PCMASK;
            } else ldm_stm(a, i);
            break;
        default:
            exception(a, (i & 0x0F000000) == 0x0F000000 ? 0x08 : 0x04, M_SVC, 4);   /* SWI / coprocessor (undefined) */
        }
    }
    if (a->abort) { a->abort = 0; exception(a, 0x10, M_SVC, 8); }
    a->pc = a->npc; a->cycles++;
}

/* ===================== sound ===================== */
static int16_t logtab[256];
static void logtab_init(void) {                         /* VIDC 8-bit log samples: bit0 sign, bits 4:1 step, bits 7:5 chord */
    int c; for (c = 0; c < 256; c++) {
        int chord = (c >> 5) & 7, point = (c >> 1) & 15, v = (((point << 1) + 33) << chord) - 33;
        logtab[c] = (int16_t)((c & 1) ? -v : v);
    }
}
static void snd_gen(Arc *a) {
    static const float GL[8] = { 0.5f, 1.0f, 0.833f, 0.667f, 0.5f, 0.333f, 0.167f, 0.0f };   /* image 1 = full left ... 7 = full right */
    float step = 1000000.0f / ARC_SND_RATE, per = (float)(a->vfreq + 2);
    int i, ch;
    a->snd_n = ARC_SND_FRAMES;
    for (i = 0; i < ARC_SND_FRAMES; i++) {
        float l = 0, r = 0;
        if (a->sdma && a->s_running) {
            a->snd_acc += step;
            while (a->snd_acc >= per && a->s_running) {             /* one sound frame = one byte per channel (8 channels) */
                a->snd_acc -= per;
                for (ch = 0; ch < 8; ch++) a->shold[ch] = logtab[a->ram[(a->s_cur + ch) % a->ram_size]];
                a->s_cur += 8;
                if (a->s_cur >= a->s_end) {
                    if (a->s_valid) { a->s_cur = a->s_nstart; a->s_end = a->s_nend; a->s_valid = 0; a->snd_irq = 1; upd_irq(a); }
                    else a->s_running = 0;                          /* nothing queued: stop */
                }
            }
            for (ch = 0; ch < 8; ch++) { float gl = GL[a->sbal[ch] & 7]; l += a->shold[ch] * gl; r += a->shold[ch] * (1.0f - gl); }
            l *= 3; r *= 3;
            if (l > 32767) l = 32767;
            if (l < -32768) l = -32768;
            if (r > 32767) r = 32767;
            if (r < -32768) r = -32768;
        } else { a->snd_acc = 0; for (ch = 0; ch < 8; ch++) a->shold[ch] = 0; }
        a->snd_out[i * 2] = (int16_t)l; a->snd_out[i * 2 + 1] = (int16_t)r;
    }
}

/* ===================== public API ===================== */
int arc_init(Arc *a, uint32_t ram_size) {
    memset(a, 0, sizeof *a);
    a->ram_size = (ram_size + 3) & ~3u; a->ram = calloc(1, a->ram_size);
    a->rom_size = 4; a->rom = calloc(1, 4); logtab_init();
    if (!a->ram || !a->rom) return -1;
    arc_reset(a); return 0;
}
int arc_rom_interleave(const uint8_t *const p[4], uint32_t n, uint8_t *out) {
    uint32_t i, check = n < 16 ? n : 16; int nat = 0, rev = 0, k;
    for (i = 0; i < check; i++) { if ((p[3][i] >> 4) == 0xE) nat++; if ((p[0][i] >> 4) == 0xE) rev++; }   /* top byte of an ARM word: condition AL = 0xE? */
    rev = rev > nat;
    for (i = 0; i < n; i++) for (k = 0; k < 4; k++) out[i * 4 + k] = p[rev ? 3 - k : k][i];
    return rev;
}
int arc_load_rom(Arc *a, const uint8_t *rom, uint32_t size) {
    uint8_t *n = malloc(size); if (!n || size < 4 || (size & 3)) { free(n); return -1; }
    memcpy(n, rom, size); free(a->rom); a->rom = n; a->rom_size = size; arc_reset(a); return 0;
}
void arc_reset(Arc *a) {
    int i;
    memset(a->r, 0, sizeof a->r); memset(a->bank, 0, sizeof a->bank); memset(a->shared, 0, sizeof a->shared);
    memset(a->lpn_ppn, 0xFF, sizeof a->lpn_ppn); memset(a->ppn_lpn, 0xFF, sizeof a->ppn_lpn);
    a->mode = M_SVC; a->I = a->F = 1; a->N = a->Z = a->C = a->V = 0; a->abort = 0;
    a->pc = a->npc = 0; a->rom_high = 0; a->irq = a->fiq = 0; a->pagesize = 0; a->vdma = 0;
    a->vinit = a->vstart = a->vend = a->cinit = 0; a->vctl = 0; memset(a->vreg, 0, sizeof a->vreg);
    for (i = 0; i < 16; i++) a->pal[i] = (uint16_t)(i * 0x111);
    a->irqA_edge = 0x10 /* power-on reset */; a->irqA_mask = a->irqB_mask = a->fiq_mask = 0;
    memset(a->t_latch, 0, sizeof a->t_latch); memset(a->t_count, 0, sizeof a->t_count); a->t_acc = 0;
    a->i2c_scl = a->i2c_sdam = a->i2c_sdas = 1; a->i2c_mode = 0;
    a->kart_full = 0; a->kb_state = 0; a->kb_wait = 0; a->kq_n = a->kq_h = 0; a->mdx = a->mdy = 0;
    a->fdc_state = 0; a->fdc_irq = a->fdc_drq = 0; a->fdc_status = 0; a->fdc_track = a->fdc_sector = 0; a->fdc_dir = 1;
    a->latch_a = 0xFF; a->latch_set = 0; memset(a->head_track, 0, sizeof a->head_track);
    memset(a->ram, 0, a->ram_size); a->cycles = 0; a->unk_count = 0;
    a->sdma = a->s_valid = a->s_running = a->snd_irq = 0; a->vfreq = 0; memset(a->sbal, 0, sizeof a->sbal); memset(a->shold, 0, sizeof a->shold); a->snd_acc = 0; a->snd_n = 0;
}
void arc_free(Arc *a) {
    int i; for (i = 0; i < ARC_NDRIVES; i++) arc_disk_eject(a, i);
    free(a->rom); free(a->ram); a->rom = a->ram = NULL;
}
void arc_frame(Arc *a) {
    int i, j;
    a->irqA_edge |= 0x08;                                 /* vsync */
    upd_irq(a);
    for (i = 0; i < 625; i++) { for (j = 0; j < 256; j++) step(a); hw_tick(a, 256); }
    snd_gen(a);
    if (a->fdd_activity > 0) a->fdd_activity--;
}

/* ---- floppy images ---- */
static int geometry(Floppy *f, long size) {
    int t, s, spt, ss, first;
    switch (size) {
    case 163840:  t = 40; s = 1; spt = 16; ss = 256;  first = 0; break;   /* ADFS S */
    case 327680:  t = 80; s = 1; spt = 16; ss = 256;  first = 0; break;   /* ADFS M */
    case 655360:  t = 80; s = 2; spt = 16; ss = 256;  first = 0; break;   /* ADFS L */
    case 819200:  t = 80; s = 2; spt = 5;  ss = 1024; first = 0; break;   /* ADFS D/E */
    case 1638400: t = 80; s = 2; spt = 10; ss = 1024; first = 0; break;   /* ADFS F */
    case 737280:  t = 80; s = 2; spt = 9;  ss = 512;  first = 1; break;   /* DOS 720K */
    case 1474560: t = 80; s = 2; spt = 18; ss = 512;  first = 1; break;   /* DOS 1.44M */
    default: return -1;
    }
    f->tracks = t; f->sides = s; f->spt = spt; f->ssize = ss; f->first = first; return 0;
}
int arc_disk_insert(Arc *a, int d, const char *path) {
    Floppy *f; FILE *fp; long size; uint8_t *buf; int wr = 1;
    if (d < 0 || d >= ARC_NDRIVES) return -1;
    fp = fopen(path, "r+b"); if (!fp) { fp = fopen(path, "rb"); wr = 0; } if (!fp) return -1;
    fseek(fp, 0, SEEK_END); size = ftell(fp); fseek(fp, 0, SEEK_SET);
    f = &a->fdd[d]; arc_disk_eject(a, d);
    if (geometry(f, size) < 0) { fclose(fp); return -2; }
    buf = malloc((size_t)size);
    if (!buf || fread(buf, 1, (size_t)size, fp) != (size_t)size) { free(buf); fclose(fp); return -3; }
    f->data = buf; f->size = (uint32_t)size; f->fp = fp; f->writable = wr; f->protect = !wr; f->inserted = 1;
    strncpy(f->path, path, sizeof f->path - 1); f->path[sizeof f->path - 1] = 0;
    return 0;
}
void arc_disk_eject(Arc *a, int d) {
    Floppy *f = &a->fdd[d];
    if (f->fp) fclose(f->fp);
    free(f->data); memset(f, 0, sizeof *f);
}
void arc_cmos_load(Arc *a, const char *path) { FILE *f = fopen(path, "rb"); if (f) { if (fread(a->cmos, 1, 256, f) != 256) memset(a->cmos, 0, 256); fclose(f); } }
void arc_cmos_save(const Arc *a, const char *path) { FILE *f = fopen(path, "wb"); if (f) { fwrite(a->cmos, 1, 256, f); fclose(f); } }


/* ===================== save states ===================== */
typedef struct { char magic[8]; uint32_t version, arc_size, ram_size, rom_size, rom_hash; char disks[ARC_NDRIVES][512]; } StateHdr;
static uint32_t fnv1a(const uint8_t *p, uint32_t n) { uint32_t h = 2166136261u; while (n--) { h ^= *p++; h *= 16777619u; } return h; }

int arc_state_save(Arc *a, const char *path) {
    StateHdr h; FILE *f; char tmp[1100]; int i, ok;
    memset(&h, 0, sizeof h);
    memcpy(h.magic, "ARCSTATE", 8); h.version = 1; h.arc_size = (uint32_t)sizeof(Arc);
    h.ram_size = a->ram_size; h.rom_size = a->rom_size; h.rom_hash = fnv1a(a->rom, a->rom_size);
    for (i = 0; i < ARC_NDRIVES; i++) if (a->fdd[i].inserted) strncpy(h.disks[i], a->fdd[i].path, sizeof h.disks[i] - 1);
    snprintf(tmp, sizeof tmp, "%s.tmp", path);
    f = fopen(tmp, "wb"); if (!f) return -1;
    ok = fwrite(&h, sizeof h, 1, f) == 1 && fwrite(a, sizeof *a, 1, f) == 1 && fwrite(a->ram, 1, a->ram_size, f) == a->ram_size;
    if (fclose(f) != 0) ok = 0;
    if (!ok || rename(tmp, path) != 0) { remove(tmp); return -1; }
    return 0;
}

int arc_state_load(Arc *a, const char *path) {
    StateHdr h; FILE *f = fopen(path, "rb"); Arc *t; uint8_t *ram; int i, warn = 0;
    if (!f) return -1;
    if (fread(&h, sizeof h, 1, f) != 1 || memcmp(h.magic, "ARCSTATE", 8) || h.version != 1 ||
        h.arc_size != (uint32_t)sizeof(Arc) || h.ram_size != a->ram_size) { fclose(f); return -2; }
    if (h.rom_size != a->rom_size || h.rom_hash != fnv1a(a->rom, a->rom_size)) { fclose(f); return -3; }
    t = malloc(sizeof *t); ram = malloc(a->ram_size);
    if (!t || !ram || fread(t, sizeof *t, 1, f) != 1 || fread(ram, 1, a->ram_size, f) != a->ram_size) {
        free(t); free(ram); fclose(f); return -2;
    }
    fclose(f);
    t->rom = a->rom; t->ram = a->ram; t->rom_size = a->rom_size; t->ram_size = a->ram_size;   /* keep live buffers */
    memcpy(t->fdd, a->fdd, sizeof t->fdd); t->trace = a->trace;                                /* keep open disk handles */
    memcpy(a, t, sizeof *a); memcpy(a->ram, ram, a->ram_size); free(t); free(ram);
    for (i = 0; i < ARC_NDRIVES; i++) {                                                        /* make the drives match the state */
        h.disks[i][sizeof h.disks[i] - 1] = 0;
        if (h.disks[i][0]) { if (!a->fdd[i].inserted || strcmp(a->fdd[i].path, h.disks[i]) != 0) if (arc_disk_insert(a, i, h.disks[i]) != 0) warn = 1; }
        else if (a->fdd[i].inserted) arc_disk_eject(a, i);
    }
    upd_irq(a);
    return warn;
}

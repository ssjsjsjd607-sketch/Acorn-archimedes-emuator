#pragma once
#include <cstdint>
// Sound output through SDL (works on Android, iOS, Linux, macOS). 44.1 kHz stereo, push model.
namespace audio {
bool init();
void shutdown();
void push(const int16_t *stereo, int frames);   // call once per emulated 20 ms frame
void clear();                                   // flush queued audio (pause / power off)
void set_volume(float v); float volume();
void set_mute(bool m);    bool muted();
}

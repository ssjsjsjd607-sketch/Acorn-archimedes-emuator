#pragma once
#include <SDL.h>
#include <string>
#include "arc.h"

// Controllers (Bluetooth or USB, via SDL's GameController API), touch controls and the on-screen keyboard.
namespace input {
void init(Arc *a, const std::string &pref_dir);
void shutdown();
bool touch_mode();                                   // true on Android / iOS
void handle_event(const SDL_Event &e, int win_w, int win_h, bool active, const SDL_Rect *screen_rect);
void per_frame(bool active);                         // sticks -> keys/mouse, delayed click releases
void release_all();                                  // lift every held key (pause / power off)
void draw_pad_panel();                               // ImGui: connected controllers + button mapping
void draw_virtual_keyboard(bool *open);              // ImGui: on-screen keyboard overlay
void draw_touch_controls(const SDL_Rect *screen_rect, bool active);   // on-screen joystick / D-pad + action buttons (multi-touch)
void draw_touch_panel();                             // ImGui: settings for the on-screen controls
}

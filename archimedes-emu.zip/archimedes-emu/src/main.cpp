// Archimedes emulator front end: SDL2 + Dear ImGui (modern dark UI).
#include <SDL.h>
#if defined(__APPLE__)
#include <TargetConditionals.h>
#endif
#include <algorithm>
#include <cctype>
#include <chrono>
#include <ctime>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <functional>
#include <string>
#include <vector>
#include "imgui.h"
#include "imgui_impl_sdl2.h"
#include "imgui_impl_sdlrenderer2.h"
#include "arc.h"
#include "audio.h"
#include "input.h"
#include "platform.h"

namespace fs = std::filesystem;

static Arc g_arc;
static std::string g_pref, g_rom_name, g_msg;
static bool g_rom_ok = false, g_powered = false, g_paused = false, g_captured = false, g_bios_modal = false;
static bool g_vkb = false;
static SDL_Rect g_screen_rect = { 0, 0, 0, 0 };
static float sc() { return ImGui::GetFontSize() / 17.f; }   // UI scale (phones are much denser)
static SDL_Window *g_win = nullptr;
static bool g_fullscreen = true, g_auto_game = true, g_game_view = false;   // fullscreen is the default
static std::string g_toast; static Uint32 g_toast_t = 0;
static void toast(const std::string &m) { g_toast = m; g_toast_t = SDL_GetTicks(); }
struct Settings { int fullscreen = 1, auto_game = 1; };
static void save_settings() {
    FILE *f = fopen((g_pref + "settings.cfg").c_str(), "wb"); if (!f) return;
    Settings st; st.fullscreen = g_fullscreen; st.auto_game = g_auto_game; fwrite(&st, sizeof st, 1, f); fclose(f);
}
static void load_settings() {
    FILE *f = fopen((g_pref + "settings.cfg").c_str(), "rb"); if (!f) return;
    Settings st; if (fread(&st, sizeof st, 1, f) == 1) { g_fullscreen = st.fullscreen != 0; g_auto_game = st.auto_game != 0; }
    fclose(f);
}
static void set_fullscreen(bool on) {
    g_fullscreen = on; if (g_win) SDL_SetWindowFullscreen(g_win, on ? SDL_WINDOW_FULLSCREEN_DESKTOP : 0); save_settings();
}

// ---------- helpers ----------
static bool read_file(const std::string &p, std::vector<uint8_t> &out) {
    std::ifstream f(p, std::ios::binary); if (!f) return false;
    out.assign(std::istreambuf_iterator<char>(f), {}); return true;
}
static std::string lower(std::string s) { for (auto &c : s) c = (char)std::tolower((unsigned char)c); return s; }
static bool is_disk_ext(const std::string &p) {
    std::string e = lower(fs::path(p).extension().string());
    return e == ".adf" || e == ".adl" || e == ".img" || e == ".dsc" || e == ".ima";
}
static bool load_rom_bytes(const std::vector<uint8_t> &d, const std::string &name) {
    if (d.size() < 262144 || d.size() > 8u * 1024 * 1024 || (d.size() & 3)) {
        g_msg = "That file doesn't look like a RISC OS ROM (expected 256 KB - 8 MB)."; return false; }
    if (arc_load_rom(&g_arc, d.data(), (uint32_t)d.size())) { g_msg = "Could not load ROM."; return false; }
    g_rom_ok = true; g_rom_name = name; g_msg.clear(); return true;
}
static int ic_index(const std::string &name) {            // IC24..IC27 -> 0..3: the four chips of a RISC OS 3.1x ROM set
    std::string n = lower(name);
    for (int i = 0; i < 4; i++) if (n.find("ic" + std::to_string(24 + i)) != std::string::npos) return i;
    return -1;
}
static std::string part_path(int i) { return g_pref + "romparts/ic" + std::to_string(24 + i) + ".rom"; }
static void store_rom(const std::vector<uint8_t> &d) {     // keep a copy for next launch
    std::ofstream o(g_pref + "riscos.rom", std::ios::binary); o.write((const char *)d.data(), (std::streamsize)d.size());
}
static void import_rom(const std::string &path) {
    std::vector<uint8_t> d; if (!read_file(path, d)) { g_msg = "Cannot read file."; return; }
    int ic = ic_index(fs::path(path).filename().string());
    if (ic >= 0 && d.size() >= 131072 && d.size() <= 2u * 1024 * 1024 && (d.size() & 3) == 0) {      // one chip of a set
        std::error_code ec; fs::create_directories(g_pref + "romparts", ec);
        { std::ofstream o(part_path(ic), std::ios::binary); o.write((const char *)d.data(), (std::streamsize)d.size()); }
        std::vector<uint8_t> part[4]; int have = 0;
        for (int i = 0; i < 4; i++) {
            if (!read_file(part_path(i), part[i])) continue;
            if (part[i].size() != d.size()) { fs::remove(part_path(i), ec); part[i].clear(); continue; }   // stale chip from another set
            have++;
        }
        if (have < 4) { g_msg.clear(); toast("Got chip IC" + std::to_string(24 + ic) + " (" + std::to_string(have) + " of 4). Import the other IC24-IC27 files too."); return; }
        const uint8_t *p[4] = { part[0].data(), part[1].data(), part[2].data(), part[3].data() };
        std::vector<uint8_t> rom(d.size() * 4);
        int rev = arc_rom_interleave(p, (uint32_t)d.size(), rom.data());
        if (!load_rom_bytes(rom, "RISC OS ROM set (IC24-IC27)")) return;
        store_rom(rom); g_powered = false;
        toast(rev ? "ROM set combined (chip order detected as reversed)" : "ROM set combined from IC24-IC27");
        return;
    }
    if (!load_rom_bytes(d, fs::path(path).filename().string())) return;
    store_rom(d); g_powered = false;
}
static void insert_disk(int drive, const std::string &path) {
    int r = arc_disk_insert(&g_arc, drive, path.c_str());
    if (r == -1) g_msg = "Cannot open disk image.";
    else if (r == -2) g_msg = "Unsupported disk image size (need ADFS S/M/L/D/E/F or DOS 720K/1.44M).";
    else if (r < 0) g_msg = "Failed to read disk image.";
    else g_msg.clear();
}
static void power_on() { if (!g_rom_ok) { g_bios_modal = true; return; } arc_reset(&g_arc); g_powered = true; g_paused = false; if (g_auto_game) g_game_view = true; }

// ---------- Archimedes key numbers ----------
static int keynum(SDL_Scancode s) {
    switch (s) {
    case SDL_SCANCODE_ESCAPE: return 0x00; case SDL_SCANCODE_GRAVE: return 0x10;
    case SDL_SCANCODE_1: return 0x11; case SDL_SCANCODE_2: return 0x12; case SDL_SCANCODE_3: return 0x13;
    case SDL_SCANCODE_4: return 0x14; case SDL_SCANCODE_5: return 0x15; case SDL_SCANCODE_6: return 0x16;
    case SDL_SCANCODE_7: return 0x17; case SDL_SCANCODE_8: return 0x18; case SDL_SCANCODE_9: return 0x19;
    case SDL_SCANCODE_0: return 0x1A; case SDL_SCANCODE_MINUS: return 0x1B; case SDL_SCANCODE_EQUALS: return 0x1C;
    case SDL_SCANCODE_BACKSPACE: return 0x1E; case SDL_SCANCODE_INSERT: return 0x1F; case SDL_SCANCODE_HOME: return 0x20;
    case SDL_SCANCODE_PAGEUP: return 0x21; case SDL_SCANCODE_TAB: return 0x26;
    case SDL_SCANCODE_Q: return 0x27; case SDL_SCANCODE_W: return 0x28; case SDL_SCANCODE_E: return 0x29;
    case SDL_SCANCODE_R: return 0x2A; case SDL_SCANCODE_T: return 0x2B; case SDL_SCANCODE_Y: return 0x2C;
    case SDL_SCANCODE_U: return 0x2D; case SDL_SCANCODE_I: return 0x2E; case SDL_SCANCODE_O: return 0x2F;
    case SDL_SCANCODE_P: return 0x30; case SDL_SCANCODE_LEFTBRACKET: return 0x31; case SDL_SCANCODE_RIGHTBRACKET: return 0x32;
    case SDL_SCANCODE_BACKSLASH: return 0x33; case SDL_SCANCODE_DELETE: return 0x34; case SDL_SCANCODE_END: return 0x35;
    case SDL_SCANCODE_PAGEDOWN: return 0x36; case SDL_SCANCODE_LCTRL: return 0x3B;
    case SDL_SCANCODE_A: return 0x3C; case SDL_SCANCODE_S: return 0x3D; case SDL_SCANCODE_D: return 0x3E;
    case SDL_SCANCODE_F: return 0x3F; case SDL_SCANCODE_G: return 0x40; case SDL_SCANCODE_H: return 0x41;
    case SDL_SCANCODE_J: return 0x42; case SDL_SCANCODE_K: return 0x43; case SDL_SCANCODE_L: return 0x44;
    case SDL_SCANCODE_SEMICOLON: return 0x45; case SDL_SCANCODE_APOSTROPHE: return 0x46; case SDL_SCANCODE_RETURN: return 0x47;
    case SDL_SCANCODE_LSHIFT: return 0x4C; case SDL_SCANCODE_Z: return 0x4E; case SDL_SCANCODE_X: return 0x4F;
    case SDL_SCANCODE_C: return 0x50; case SDL_SCANCODE_V: return 0x51; case SDL_SCANCODE_B: return 0x52;
    case SDL_SCANCODE_N: return 0x53; case SDL_SCANCODE_M: return 0x54; case SDL_SCANCODE_COMMA: return 0x55;
    case SDL_SCANCODE_PERIOD: return 0x56; case SDL_SCANCODE_SLASH: return 0x57; case SDL_SCANCODE_RSHIFT: return 0x58;
    case SDL_SCANCODE_UP: return 0x59; case SDL_SCANCODE_CAPSLOCK: return 0x5D; case SDL_SCANCODE_LALT: return 0x5E;
    case SDL_SCANCODE_SPACE: return 0x5F; case SDL_SCANCODE_RALT: return 0x60; case SDL_SCANCODE_RCTRL: return 0x61;
    case SDL_SCANCODE_LEFT: return 0x62; case SDL_SCANCODE_DOWN: return 0x63; case SDL_SCANCODE_RIGHT: return 0x64;
    case SDL_SCANCODE_F1: return 0x01; case SDL_SCANCODE_F2: return 0x02; case SDL_SCANCODE_F3: return 0x03;
    case SDL_SCANCODE_F4: return 0x04; case SDL_SCANCODE_F5: return 0x05; case SDL_SCANCODE_F6: return 0x06;
    case SDL_SCANCODE_F7: return 0x07; case SDL_SCANCODE_F8: return 0x08; case SDL_SCANCODE_F9: return 0x09;
    case SDL_SCANCODE_F10: return 0x0A; case SDL_SCANCODE_F11: return 0x0B;
    case SDL_SCANCODE_KP_7: return 0x37; case SDL_SCANCODE_KP_8: return 0x38; case SDL_SCANCODE_KP_9: return 0x39;
    case SDL_SCANCODE_KP_MINUS: return 0x3A; case SDL_SCANCODE_KP_4: return 0x48; case SDL_SCANCODE_KP_5: return 0x49;
    case SDL_SCANCODE_KP_6: return 0x4A; case SDL_SCANCODE_KP_PLUS: return 0x4B; case SDL_SCANCODE_KP_1: return 0x5A;
    case SDL_SCANCODE_KP_2: return 0x5B; case SDL_SCANCODE_KP_3: return 0x5C; case SDL_SCANCODE_KP_0: return 0x65;
    case SDL_SCANCODE_KP_PERIOD: return 0x66; case SDL_SCANCODE_KP_ENTER: return 0x67;
    case SDL_SCANCODE_KP_DIVIDE: return 0x23; case SDL_SCANCODE_KP_MULTIPLY: return 0x24;
    default: return -1;
    }
}

// ---------- in-app file browser ----------
struct FileDlg {
    bool want = false; std::string title; fs::path dir; std::vector<std::string> exts;
    std::function<void(const std::string &)> cb;
} g_dlg;
static void open_dialog(const char *title, std::vector<std::string> exts, std::function<void(const std::string &)> cb) {
    g_dlg.title = title; g_dlg.exts = std::move(exts); g_dlg.cb = std::move(cb); g_dlg.want = true;
    if (g_dlg.dir.empty() || !fs::exists(g_dlg.dir)) {
        const char *h = SDL_getenv("HOME"); g_dlg.dir = h ? h : fs::current_path().string();
#if defined(__APPLE__) && TARGET_OS_IPHONE
        g_dlg.dir /= "Documents";                       // visible in the Files app (UIFileSharingEnabled)
        std::error_code mk; fs::create_directories(g_dlg.dir, mk);
#endif
    }
}
static void draw_dialog() {
    if (g_dlg.want) { ImGui::OpenPopup(g_dlg.title.c_str()); g_dlg.want = false; }
    ImGui::SetNextWindowSize(ImVec2(680 * sc(), 480 * sc()), ImGuiCond_Appearing);
    ImGui::SetNextWindowPos(ImGui::GetMainViewport()->GetCenter(), ImGuiCond_Appearing, ImVec2(0.5f, 0.5f));
    if (!ImGui::BeginPopupModal(g_dlg.title.c_str(), nullptr, ImGuiWindowFlags_NoSavedSettings)) return;
    ImGui::TextDisabled("%s", g_dlg.dir.string().c_str());
    if (ImGui::Button("Up") && g_dlg.dir.has_parent_path()) g_dlg.dir = g_dlg.dir.parent_path();
    ImGui::SameLine(); ImGui::TextDisabled("(you can also drag and drop a file onto the window)");
    std::vector<fs::directory_entry> dirs, files; std::error_code ec;
    for (fs::directory_iterator it(g_dlg.dir, ec), end; !ec && it != end; it.increment(ec)) {
        std::string n = it->path().filename().string(); if (n.empty() || n[0] == '.') continue;
        std::error_code e2;
        if (it->is_directory(e2)) dirs.push_back(*it);
        else { std::string x = lower(it->path().extension().string());
               if (g_dlg.exts.empty() || std::find(g_dlg.exts.begin(), g_dlg.exts.end(), x) != g_dlg.exts.end()) files.push_back(*it); }
    }
    auto byname = [](const fs::directory_entry &a, const fs::directory_entry &b) { return lower(a.path().filename().string()) < lower(b.path().filename().string()); };
    std::sort(dirs.begin(), dirs.end(), byname); std::sort(files.begin(), files.end(), byname);
    ImGui::BeginChild("list", ImVec2(0, -ImGui::GetFrameHeightWithSpacing() - 4), true);
    for (auto &d : dirs)
        if (ImGui::Selectable(("[ ] " + d.path().filename().string()).c_str())) { g_dlg.dir = d.path(); break; }
    for (auto &f : files)
        if (ImGui::Selectable(f.path().filename().string().c_str())) {
            auto cb = g_dlg.cb; std::string p = f.path().string(); ImGui::CloseCurrentPopup(); if (cb) cb(p); break; }
    ImGui::EndChild();
    if (ImGui::Button("Cancel")) ImGui::CloseCurrentPopup();
    ImGui::EndPopup();
}

// ---------- save states ----------
static int g_slot = 1;
static std::string slot_path(int s) {
    std::error_code ec; fs::create_directories(g_pref + "states", ec);
    return g_pref + "states/slot" + std::to_string(s) + ".state";
}
static std::string slot_info(int s) {
    std::error_code ec; std::string p = slot_path(s);
    if (!fs::exists(p, ec)) return "Empty";
    auto ft = fs::last_write_time(p, ec); if (ec) return "Saved";
    auto sc = std::chrono::time_point_cast<std::chrono::system_clock::duration>(ft - fs::file_time_type::clock::now() + std::chrono::system_clock::now());
    std::time_t tt = std::chrono::system_clock::to_time_t(sc); char b[48];
    std::strftime(b, sizeof b, "Saved %d %b %H:%M", std::localtime(&tt)); return b;
}
static void state_save() {
    if (!g_powered) { toast("Power on first"); return; }
    toast(arc_state_save(&g_arc, slot_path(g_slot).c_str()) == 0 ? "Saved to slot " + std::to_string(g_slot) : "Save failed");
}
static void state_load() {
    if (!g_rom_ok) { g_bios_modal = true; return; }
    int r = arc_state_load(&g_arc, slot_path(g_slot).c_str());
    if (r == -1) toast("Slot " + std::to_string(g_slot) + " is empty");
    else if (r == -3) toast("That state was saved with a different ROM");
    else if (r < 0) toast("State is incompatible with this version");
    else { g_powered = true; g_paused = false; if (g_auto_game) g_game_view = true; audio::clear(); input::release_all();
           toast(r == 0 ? "Loaded slot " + std::to_string(g_slot) : "Loaded, but a disk image is missing"); }
}

static void pick_rom() {
    if (platform::native_picker()) platform::pick(0);
    else open_dialog("Import RISC OS ROM", {}, [](const std::string &p) { import_rom(p); });
}
static void pick_disk(int i) {
    if (!g_rom_ok) { g_bios_modal = true; return; }
    if (platform::native_picker()) platform::pick(i + 1);
    else open_dialog("Insert floppy", { ".adf", ".adl", ".img", ".dsc", ".ima" }, [i](const std::string &p) { insert_disk(i, p); });
}

// ---------- theme ----------
static void apply_theme() {
    ImGuiStyle &s = ImGui::GetStyle();
    s.WindowRounding = 14; s.ChildRounding = 12; s.FrameRounding = 9; s.PopupRounding = 12; s.GrabRounding = 9;
    s.WindowPadding = ImVec2(16, 14); s.FramePadding = ImVec2(14, 8); s.ItemSpacing = ImVec2(10, 10); s.WindowBorderSize = 0; s.ChildBorderSize = 1;
    ImVec4 *c = s.Colors;
    auto rgb = [](int r, int g, int b, float a = 1.f) { return ImVec4(r / 255.f, g / 255.f, b / 255.f, a); };
    c[ImGuiCol_WindowBg] = rgb(13, 15, 20);       c[ImGuiCol_ChildBg] = rgb(22, 26, 34);   c[ImGuiCol_PopupBg] = rgb(24, 28, 38);
    c[ImGuiCol_Border] = rgb(44, 50, 66);         c[ImGuiCol_Text] = rgb(232, 236, 245);   c[ImGuiCol_TextDisabled] = rgb(128, 137, 158);
    c[ImGuiCol_Button] = rgb(40, 46, 62);         c[ImGuiCol_ButtonHovered] = rgb(62, 70, 96); c[ImGuiCol_ButtonActive] = rgb(124, 108, 255);
    c[ImGuiCol_FrameBg] = rgb(32, 37, 50);        c[ImGuiCol_CheckMark] = rgb(150, 136, 255);
    c[ImGuiCol_Header] = rgb(40, 46, 62);         c[ImGuiCol_HeaderHovered] = rgb(62, 70, 96); c[ImGuiCol_HeaderActive] = rgb(124, 108, 255);
    c[ImGuiCol_ModalWindowDimBg] = rgb(0, 0, 0, 0.65f);
}
static bool accent_button(const char *l, bool enabled = true, ImVec2 sz = ImVec2(0, 0)) {
    ImGui::BeginDisabled(!enabled);
    ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.486f, 0.424f, 1.f, 1.f));
    ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.58f, 0.52f, 1.f, 1.f));
    bool r = ImGui::Button(l, sz); ImGui::PopStyleColor(2); ImGui::EndDisabled(); return r;
}
static void chip(const char *text, ImVec4 col) {
    ImVec2 p = ImGui::GetCursorScreenPos(), ts = ImGui::CalcTextSize(text), sz(ts.x + 26, ts.y + 10);
    ImDrawList *dl = ImGui::GetWindowDrawList();
    dl->AddRectFilled(p, ImVec2(p.x + sz.x, p.y + sz.y), ImGui::ColorConvertFloat4ToU32(ImVec4(col.x, col.y, col.z, 0.18f)), sz.y / 2);
    dl->AddCircleFilled(ImVec2(p.x + 12, p.y + sz.y / 2), 4, ImGui::ColorConvertFloat4ToU32(col));
    dl->AddText(ImVec2(p.x + 22, p.y + 5), ImGui::ColorConvertFloat4ToU32(ImVec4(0.9f, 0.92f, 0.97f, 1)), text);
    ImGui::Dummy(sz);
}

// ---------- drive card ----------
static void drive_card(int i) {
    Floppy &f = g_arc.fdd[i]; ImGui::PushID(i);
    ImGui::BeginChild("drive", ImVec2(0, 132 * sc()), true);
    char letter[2] = { (char)('A' + i), 0 };
    ImDrawList *dl = ImGui::GetWindowDrawList(); ImVec2 p = ImGui::GetCursorScreenPos();
    float ik = 44 * sc();
    dl->AddRectFilled(p, ImVec2(p.x + ik, p.y + ik), IM_COL32(124, 108, 255, f.inserted ? 255 : 70), 12 * sc());
    dl->AddText(ImVec2(p.x + ik * 0.36f, p.y + ik * 0.28f), IM_COL32(255, 255, 255, 255), letter);
    ImGui::Dummy(ImVec2(ik, ik)); ImGui::SameLine();
    ImGui::BeginGroup();
    ImGui::Text("Floppy %s  (:%d)", letter, i);
    std::string nm = f.inserted ? fs::path(f.path).filename().string() : "Empty";
    ImGui::TextDisabled("%s", nm.c_str());
    ImGui::EndGroup();
    bool busy = g_arc.fdd_activity > 0 && g_arc.fdc_drive == i;
    ImGui::SameLine(ImGui::GetContentRegionMax().x - 20);
    ImVec2 q = ImGui::GetCursorScreenPos();
    dl->AddCircleFilled(ImVec2(q.x + 6, q.y + 12), 6, busy ? IM_COL32(255, 170, 60, 255) : IM_COL32(70, 76, 94, 255));
    ImGui::Dummy(ImVec2(14, 24));
    if (accent_button("Insert...")) pick_disk(i);
    ImGui::SameLine(); ImGui::BeginDisabled(!f.inserted);
    if (ImGui::Button("Eject")) arc_disk_eject(&g_arc, i);
    ImGui::SameLine(); bool wp = f.protect != 0;
    if (ImGui::Checkbox("Write-protect", &wp)) f.protect = wp || !f.writable;
    ImGui::EndDisabled();
    ImGui::EndChild(); ImGui::PopID();
}

// ---------- full-screen game view ----------
static void draw_game_view(ImGuiViewport *vp, SDL_Texture *tex) {
    ImVec2 ws = vp->WorkSize, wp = vp->WorkPos;
    float dw = ws.x, dh = dw * 3.f / 4.f; if (dh > ws.y) { dh = ws.y; dw = dh * 4.f / 3.f; }
    float x = wp.x + (ws.x - dw) * 0.5f, y = wp.y + (ws.y - dh) * 0.5f;
    ImGui::SetNextWindowPos(wp); ImGui::SetNextWindowSize(ws);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
    ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0, 0, 0, 1));
    ImGui::Begin("game", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings |
                 ImGuiWindowFlags_NoBringToFrontOnFocus | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse);
    ImGui::SetCursorScreenPos(ImVec2(x, y));
    if (tex) ImGui::Image((ImTextureID)tex, ImVec2(dw, dh)); else ImGui::Dummy(ImVec2(dw, dh));
    if (!input::touch_mode() && ImGui::IsItemClicked() && !g_paused) { g_captured = true; SDL_SetRelativeMouseMode(SDL_TRUE); }
    ImGui::End(); ImGui::PopStyleColor(); ImGui::PopStyleVar();
    g_screen_rect = { (int)x, (int)y, (int)dw, (int)dh };

    ImDrawList *fg = ImGui::GetForegroundDrawList();
    if (g_paused) { const char *t = "PAUSED"; ImVec2 ts = ImGui::CalcTextSize(t); fg->AddText(ImVec2(x + (dw - ts.x) / 2, y + dh * 0.45f), IM_COL32(255, 255, 255, 200), t); }
    if (!g_toast.empty() && SDL_GetTicks() - g_toast_t < 2500) {
        ImVec2 ts = ImGui::CalcTextSize(g_toast.c_str());
        fg->AddText(ImVec2(x + (dw - ts.x) / 2, y + 12 * sc()), IM_COL32(120, 255, 170, 230), g_toast.c_str());
    }

    ImGui::SetNextWindowPos(ImVec2(wp.x + ws.x - 8 * sc(), wp.y + 8 * sc()), ImGuiCond_Always, ImVec2(1, 0));
    ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.05f, 0.06f, 0.09f, 0.6f));
    ImGui::Begin("gamebar", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoMove |
                 ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoFocusOnAppearing);
    ImVec2 bsz(78 * sc(), 0);
    if (ImGui::Button("Menu", bsz)) { g_game_view = false; g_captured = false; SDL_SetRelativeMouseMode(SDL_FALSE); input::release_all(); }
    if (ImGui::Button("Keys", bsz)) g_vkb = !g_vkb;
    if (ImGui::Button(g_paused ? "Resume" : "Pause", bsz)) { g_paused = !g_paused; input::release_all(); }
    if (ImGui::Button("Save", bsz)) state_save();
    if (ImGui::Button("Load", bsz)) state_load();
    ImVec2 p = ImGui::GetWindowPos(), sz = ImGui::GetWindowSize();
    SDL_Rect blk = { (int)p.x - 6, (int)p.y - 6, (int)sz.x + 12, (int)sz.y + 12 };
    input::set_block_rect(&blk);
    ImGui::End(); ImGui::PopStyleColor();
}

// ---------- main ----------
int main(int, char **) {
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO | SDL_INIT_GAMECONTROLLER | SDL_INIT_JOYSTICK) < 0) { fprintf(stderr, "%s\n", SDL_GetError()); return 1; }
    char *pp = SDL_GetPrefPath("archimedes-emu", "Archimedes"); g_pref = pp ? pp : ""; SDL_free(pp);
    arc_init(&g_arc, 4u * 1024 * 1024); g_arc.trace = SDL_getenv("ARC_TRACE") != nullptr;
    arc_cmos_load(&g_arc, (g_pref + "cmos.bin").c_str());
    input::init(&g_arc, g_pref);
    audio::init();
    { std::vector<uint8_t> d; if (read_file(g_pref + "riscos.rom", d)) load_rom_bytes(d, "riscos.rom (imported)"); }
    g_bios_modal = !g_rom_ok;

    load_settings();
    SDL_Window *win = SDL_CreateWindow("Archimedes", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 1280, 780,
                                       SDL_WINDOW_RESIZABLE | SDL_WINDOW_ALLOW_HIGHDPI | (g_fullscreen ? SDL_WINDOW_FULLSCREEN_DESKTOP : 0));
    g_win = win;
    SDL_Renderer *ren = SDL_CreateRenderer(win, -1, SDL_RENDERER_PRESENTVSYNC | SDL_RENDERER_ACCELERATED);
    IMGUI_CHECKVERSION(); ImGui::CreateContext();
    ImGuiIO &io = ImGui::GetIO(); io.IniFilename = nullptr;
    const char *fonts[] = { "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", "/System/Library/Fonts/Helvetica.ttc",
                            "/system/fonts/Roboto-Regular.ttf", "C:\\Windows\\Fonts\\segoeui.ttf" };
    bool font_ok = false;
    int rw = 0, rh = 0, ww0 = 0, wh0 = 0; SDL_GetRendererOutputSize(ren, &rw, &rh); SDL_GetWindowSize(win, &ww0, &wh0);
    float fbs = (ww0 > 0 && rw > 0) ? (float)rw / (float)ww0 : 1.f;      // retina / HiDPI: draw fonts at native resolution
    float ui_scale = 1.f;
#if defined(__ANDROID__)
    { float dpi = 160.f; SDL_GetDisplayDPI(0, &dpi, nullptr, nullptr); ui_scale = std::max(1.2f, dpi / 160.f); }
#elif defined(__APPLE__) && TARGET_OS_IPHONE
    ui_scale = 1.3f;
#endif
    for (const char *fp : fonts) if (fs::exists(fp)) { font_ok = io.Fonts->AddFontFromFileTTF(fp, 17.f * ui_scale * fbs) != nullptr; if (font_ok) break; }
    if (!font_ok) { ImFontConfig cfg; cfg.SizePixels = 17.f * ui_scale * fbs; io.Fonts->AddFontDefault(&cfg); }
    io.FontGlobalScale = 1.f / fbs;
    apply_theme(); ImGui::GetStyle().ScaleAllSizes(ui_scale);
    ImGui_ImplSDL2_InitForSDLRenderer(win, ren); ImGui_ImplSDLRenderer2_Init(ren);

    SDL_Texture *tex = nullptr; int tw = 0, th = 0; std::vector<uint32_t> fb(ARC_MAX_W * ARC_MAX_H);
    Uint64 last = SDL_GetPerformanceCounter(); double acc = 0; int fps_n = 0, fps = 0;
    bool run = true;

    while (run) {
        SDL_Event e;
        while (SDL_PollEvent(&e)) {
            ImGui_ImplSDL2_ProcessEvent(&e);
            bool touch = input::touch_mode(), active = g_powered && !g_paused, kbd = active && (g_captured || touch);
            int ww = 0, wh = 0; SDL_GetWindowSize(win, &ww, &wh);
            input::handle_event(e, ww, wh, active, &g_screen_rect);
            if (e.type == SDL_QUIT) run = false;
            else if (e.type == SDL_DROPFILE) {
                std::string p = e.drop.file; SDL_free(e.drop.file);
                if (is_disk_ext(p)) {
                    if (!g_rom_ok) g_bios_modal = true;
                    else for (int i = 0; i < ARC_NDRIVES; i++) if (!g_arc.fdd[i].inserted) { insert_disk(i, p); break; }
                } else import_rom(p);
            } else if ((e.type == SDL_KEYDOWN || e.type == SDL_KEYUP) && !e.key.repeat) {
                bool down = e.type == SDL_KEYDOWN;
                if (down && e.key.keysym.scancode == SDL_SCANCODE_F11 && !touch) set_fullscreen(!g_fullscreen);
                else if (down && (e.key.keysym.scancode == SDL_SCANCODE_AC_BACK || (e.key.keysym.scancode == SDL_SCANCODE_F10 && !touch))) {
                    if (g_powered) { g_game_view = !g_game_view; g_captured = false; SDL_SetRelativeMouseMode(SDL_FALSE); input::release_all(); }
                }
                else if (down && e.key.keysym.scancode == SDL_SCANCODE_F12 && !touch) { g_captured = false; SDL_SetRelativeMouseMode(SDL_FALSE); }
                else if (kbd) { int k = keynum(e.key.keysym.scancode); if (k >= 0) arc_key(&g_arc, k, down); }
            } else if (g_captured && active && e.type == SDL_MOUSEMOTION && e.motion.which != SDL_TOUCH_MOUSEID) {
                arc_mouse_move(&g_arc, e.motion.xrel, e.motion.yrel);
            } else if (g_captured && active && (e.type == SDL_MOUSEBUTTONDOWN || e.type == SDL_MOUSEBUTTONUP) && e.button.which != SDL_TOUCH_MOUSEID) {
                int b = e.button.button == SDL_BUTTON_LEFT ? 0 : e.button.button == SDL_BUTTON_MIDDLE ? 1 : e.button.button == SDL_BUTTON_RIGHT ? 2 : -1;
                if (b >= 0) arc_key(&g_arc, 0x70 + b, e.type == SDL_MOUSEBUTTONDOWN);
            } else if (e.type == SDL_WINDOWEVENT && e.window.event == SDL_WINDOWEVENT_FOCUS_LOST) {
                g_captured = false; SDL_SetRelativeMouseMode(SDL_FALSE); input::release_all();
            }
        }

        // ---- emulation at a fixed 50 Hz ----
        Uint64 now = SDL_GetPerformanceCounter(); acc += (double)(now - last) / (double)SDL_GetPerformanceFrequency(); last = now;
        if (acc > 0.1) acc = 0.1;
        while (acc >= 0.02) { acc -= 0.02; if (g_powered && !g_paused) { arc_frame(&g_arc); audio::push(g_arc.snd_out, g_arc.snd_n); fps_n++; } }
        { static bool was_running = false; bool now_running = g_powered && !g_paused; if (was_running && !now_running) audio::clear(); was_running = now_running; }
        { static Uint64 t0 = SDL_GetTicks64(); Uint64 t1 = SDL_GetTicks64(); if (t1 - t0 >= 1000) { fps = fps_n; fps_n = 0; t0 = t1; } }

        input::per_frame(g_powered && !g_paused);
        { std::string pth; int kind = 0;
          while (platform::poll_picked(pth, kind)) {
              if (kind == 0) import_rom(pth); else if (g_rom_ok) insert_disk(kind - 1, pth); else g_bios_modal = true; } }

        // ---- upload screen ----
        int w = 640, h = 256;
        if (g_powered) {
            arc_video_size(&g_arc, &w, &h);
            if (!tex || w != tw || h != th) {
                if (tex) SDL_DestroyTexture(tex);
                tex = SDL_CreateTexture(ren, SDL_PIXELFORMAT_ARGB8888, SDL_TEXTUREACCESS_STREAMING, w, h); tw = w; th = h;
                SDL_SetTextureScaleMode(tex, SDL_ScaleModeLinear);
            }
            arc_render(&g_arc, fb.data(), w, h); SDL_UpdateTexture(tex, nullptr, fb.data(), w * 4);
        }

        // ---- UI ----
        ImGui_ImplSDLRenderer2_NewFrame(); ImGui_ImplSDL2_NewFrame(); ImGui::NewFrame();
        ImGuiViewport *vp = ImGui::GetMainViewport();
        bool narrow = vp->WorkSize.x < vp->WorkSize.y * 1.15f || vp->WorkSize.x < 900.f * sc();
        bool gv = g_game_view && g_powered;
        if (gv) draw_game_view(vp, tex);
        else {
        input::set_block_rect(nullptr);
        ImGui::SetNextWindowPos(vp->WorkPos); ImGui::SetNextWindowSize(vp->WorkSize);
        ImGui::Begin("root", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoBringToFrontOnFocus);

        ImGui::TextUnformatted("ARCHIMEDES"); ImGui::SameLine(); ImGui::TextDisabled("RISC OS emulator");
        if (!narrow) ImGui::SameLine(ImGui::GetContentRegionMax().x - 520 * sc());
        if (g_rom_ok) chip("BIOS ready", ImVec4(0.35f, 0.85f, 0.55f, 1)); else chip("BIOS missing", ImVec4(1.f, 0.35f, 0.4f, 1));
        ImGui::SameLine(); chip(!g_powered ? "Off" : g_paused ? "Paused" : "Running", ImVec4(0.55f, 0.5f, 1.f, 1));
        if (g_powered) { ImGui::SameLine(); char b[32]; snprintf(b, sizeof b, "%d fps", fps); chip(b, ImVec4(0.6f, 0.65f, 0.75f, 1)); }

        float side = narrow ? 0.f : 360.f * sc(), avail_w = narrow ? ImGui::GetContentRegionAvail().x : ImGui::GetContentRegionAvail().x - side - ImGui::GetStyle().ItemSpacing.x;
        ImGui::BeginChild("screen", ImVec2(avail_w, narrow ? avail_w * 0.75f + 150.f * sc() : 0.f), true);
        ImVec2 reg = ImGui::GetContentRegionAvail(); reg.y -= 62;
        float aspect = 4.f / 3.f, dw = reg.x, dh = reg.x / aspect; if (dh > reg.y) { dh = reg.y; dw = dh * aspect; }
        ImGui::SetCursorPosX((ImGui::GetContentRegionAvail().x - dw) * 0.5f + ImGui::GetCursorPosX());
        ImVec2 sp = ImGui::GetCursorScreenPos();
        if (g_powered && tex) ImGui::Image((ImTextureID)tex, ImVec2(dw, dh));
        else {
            ImGui::GetWindowDrawList()->AddRectFilled(sp, ImVec2(sp.x + dw, sp.y + dh), IM_COL32(8, 9, 12, 255), 10);
            const char *t = g_rom_ok ? "Press Power to boot RISC OS" : "Import a RISC OS ROM (BIOS) to begin";
            ImVec2 ts = ImGui::CalcTextSize(t);
            ImGui::GetWindowDrawList()->AddText(ImVec2(sp.x + (dw - ts.x) / 2, sp.y + dh / 2 - ts.y / 2), IM_COL32(128, 137, 158, 255), t);
            ImGui::Dummy(ImVec2(dw, dh));
        }
        g_screen_rect = { (int)sp.x, (int)sp.y, (int)dw, (int)dh };
        if (g_powered && !input::touch_mode() && ImGui::IsItemClicked() && !g_paused) { g_captured = true; SDL_SetRelativeMouseMode(SDL_TRUE); }
        ImGui::Spacing();
        ImGui::BeginDisabled(!g_rom_ok);
        if (accent_button(g_powered ? "Restart" : "Power", g_rom_ok, ImVec2(104 * sc(), 0))) { input::release_all(); power_on(); }
        ImGui::EndDisabled();
        ImGui::SameLine(); if (ImGui::Button(g_paused ? "Resume" : "Pause", ImVec2(92 * sc(), 0)) && g_powered) { g_paused = !g_paused; input::release_all(); }
        ImGui::SameLine(); if (ImGui::Button("Off", ImVec2(64 * sc(), 0))) { g_powered = false; g_captured = false; SDL_SetRelativeMouseMode(SDL_FALSE); input::release_all(); }
        ImGui::SameLine(); if (ImGui::Button("Keys", ImVec2(76 * sc(), 0))) g_vkb = !g_vkb;
        if (!narrow) ImGui::SameLine();
        if (ImGui::Button("Full screen", ImVec2(124 * sc(), 0)) && g_powered) g_game_view = true;
        if (!narrow) ImGui::SameLine();
        ImGui::TextDisabled(input::touch_mode() ? "Drag = mouse, tap = click, 2-finger tap = right click" : g_captured ? "Captured - F12 to release" : "Click the screen to capture mouse + keyboard");
        ImGui::EndChild();

        if (!narrow) ImGui::SameLine();
        ImGui::BeginChild("side", ImVec2(0, 0), false);
        ImGui::TextDisabled("BIOS / ROM");
        ImGui::BeginChild("bios", ImVec2(0, 150 * sc()), true);
        ImGui::Text("%s", g_rom_ok ? g_rom_name.c_str() : "No ROM imported");
        if (g_rom_ok && g_arc.rom_size < 1024 * 1024) {
            ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1.f, 0.78f, 0.35f, 1));
            ImGui::TextWrapped("Only %u KB. RISC OS 3.1x comes as four chips (IC24-IC27, 2 MB): import all four.", g_arc.rom_size / 1024);
            ImGui::PopStyleColor();
        }
        if (!g_toast.empty() && SDL_GetTicks() - g_toast_t < 6000) { ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.45f, 0.9f, 0.6f, 1)); ImGui::TextWrapped("%s", g_toast.c_str()); ImGui::PopStyleColor(); }
        if (accent_button(g_rom_ok ? "Replace ROM..." : "Import ROM...")) pick_rom();
        ImGui::EndChild();
        ImGui::TextDisabled("FLOPPY DRIVES");
        for (int i = 0; i < ARC_NDRIVES; i++) drive_card(i);
        ImGui::TextDisabled("SAVE STATES");
        ImGui::BeginChild("states", ImVec2(0, 150 * sc()), true);
        for (int sl = 1; sl <= 4; sl++) {
            if (sl > 1) ImGui::SameLine();
            bool sel = g_slot == sl; char lb[8]; snprintf(lb, sizeof lb, "%d", sl);
            if (sel) ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.486f, 0.424f, 1.f, 1.f));
            if (ImGui::Button(lb, ImVec2(56 * sc(), 0))) g_slot = sl;
            if (sel) ImGui::PopStyleColor();
        }
        ImGui::TextDisabled("Slot %d: %s", g_slot, slot_info(g_slot).c_str());
        if (accent_button("Save state", g_powered)) state_save();
        ImGui::SameLine(); if (ImGui::Button("Load state")) state_load();
        if (!g_toast.empty() && SDL_GetTicks() - g_toast_t < 4000) { ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.45f, 0.9f, 0.6f, 1)); ImGui::TextWrapped("%s", g_toast.c_str()); ImGui::PopStyleColor(); }
        ImGui::EndChild();
        ImGui::TextDisabled("DISPLAY");
        { bool fsb = g_fullscreen; if (ImGui::Checkbox("Fullscreen window (F11)", &fsb)) set_fullscreen(fsb);
          bool ag = g_auto_game; if (ImGui::Checkbox("Full-screen game view when powering on", &ag)) { g_auto_game = ag; save_settings(); } }
        ImGui::TextDisabled("SOUND");
        { bool on = !audio::muted(); if (ImGui::Checkbox("Sound on", &on)) audio::set_mute(!on);
          ImGui::SameLine(); float v = audio::volume(); ImGui::SetNextItemWidth(-1);
          if (ImGui::SliderFloat("##vol", &v, 0.f, 1.f, "%.2f")) audio::set_volume(v); }
        if (!g_msg.empty()) { ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1.f, 0.55f, 0.55f, 1)); ImGui::TextWrapped("%s", g_msg.c_str()); ImGui::PopStyleColor(); }
        if (ImGui::CollapsingHeader("Diagnostics")) {
            ImGui::Text("PC  %07X   mode %d", g_arc.pc, g_arc.mode);
            ImGui::Text("ROM: %u KB", g_arc.rom_size / 1024);
            ImGui::Text("ROM at 0: %s", g_arc.rom_high ? "off (booted high)" : "on");
            ImGui::Text("Unmapped I/O: %d (last %08X)", g_arc.unk_count, g_arc.unk_last);
            ImGui::TextDisabled("Run with ARC_TRACE=1 to log them to stderr.");
            static char rep[2048]; arc_report(&g_arc, rep, sizeof rep);
            ImGui::Separator();
            ImGui::TextWrapped("%s", rep);
            if (accent_button("Copy report")) { ImGui::SetClipboardText(rep); toast("Report copied - paste it into the chat"); }
            ImGui::Separator();
            ImGui::TextDisabled("Screen debug");
            { bool dv = g_arc.dbg_video != 0;
              if (ImGui::Checkbox("Show raw RAM as the screen", &dv)) g_arc.dbg_video = dv;
              if (dv) {
                  int kb = (int)(g_arc.dbg_base / 1024);
                  if (ImGui::SliderInt("RAM offset (KB)", &kb, 0, (int)(g_arc.ram_size / 1024) - 300)) g_arc.dbg_base = (uint32_t)kb * 1024;
                  static const int bpps[4] = { 1, 2, 4, 8 };
                  for (int q = 0; q < 4; q++) {
                      char lb[8]; snprintf(lb, sizeof lb, "%d bpp", bpps[q]);
                      if (q) ImGui::SameLine();
                      if (ImGui::RadioButton(lb, g_arc.dbg_bpp == bpps[q])) g_arc.dbg_bpp = bpps[q];
                  }
              } }
        }
        input::draw_touch_panel();
        input::draw_pad_panel();
        ImGui::EndChild();

        // BIOS warning modal
        if (g_bios_modal) { ImGui::OpenPopup("BIOS required"); g_bios_modal = false; }
        ImGui::SetNextWindowPos(vp->GetCenter(), ImGuiCond_Always, ImVec2(0.5f, 0.5f));
        if (ImGui::BeginPopupModal("BIOS required", nullptr, ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoSavedSettings)) {
            ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1.f, 0.78f, 0.35f, 1)); ImGui::TextUnformatted("Import the BIOS before playing games"); ImGui::PopStyleColor();
            ImGui::Spacing();
            ImGui::PushTextWrapPos(430 * sc());
            ImGui::TextWrapped("This emulator needs a RISC OS ROM image (the Archimedes BIOS) to start. It is not included - import a ROM you are licensed to use. If your ROM is four files (IC24-IC27), select all four. Floppy images can be inserted once it is loaded.");
            ImGui::PopTextWrapPos(); ImGui::Spacing();
            if (accent_button("Import ROM...")) { ImGui::CloseCurrentPopup(); pick_rom(); }
            ImGui::SameLine(); if (ImGui::Button("Later")) ImGui::CloseCurrentPopup();
            ImGui::EndPopup();
        }
        draw_dialog();
        ImGui::End();
        }
        input::draw_touch_controls(&g_screen_rect, g_powered && !g_paused);
        input::draw_virtual_keyboard(&g_vkb);

        ImGui::Render();
        SDL_SetRenderDrawColor(ren, 13, 15, 20, 255); SDL_RenderClear(ren);
        ImGui_ImplSDLRenderer2_RenderDrawData(ImGui::GetDrawData(), ren); SDL_RenderPresent(ren);
    }
    audio::shutdown();
    input::shutdown();
    arc_cmos_save(&g_arc, (g_pref + "cmos.bin").c_str());
    arc_free(&g_arc);
    ImGui_ImplSDLRenderer2_Shutdown(); ImGui_ImplSDL2_Shutdown(); ImGui::DestroyContext();
    if (tex) SDL_DestroyTexture(tex); SDL_DestroyRenderer(ren); SDL_DestroyWindow(win); SDL_Quit();
    return 0;
}

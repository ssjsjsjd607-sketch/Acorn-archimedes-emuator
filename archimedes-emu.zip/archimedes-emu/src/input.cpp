#include "input.h"
#include "imgui.h"
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <vector>
#if defined(__APPLE__)
#include <TargetConditionals.h>
#endif

namespace input {

struct KeyName { const char *n; int k; };
static const KeyName KEYS[] = {
    {"None", -1}, {"Up", 0x59}, {"Down", 0x63}, {"Left", 0x62}, {"Right", 0x64},
    {"Space", 0x5F}, {"Return", 0x47}, {"Escape", 0x00}, {"Tab", 0x26}, {"Backspace", 0x1E},
    {"Left Shift", 0x4C}, {"Right Shift", 0x58}, {"Left Ctrl", 0x3B}, {"Right Ctrl", 0x61},
    {"Left Alt", 0x5E}, {"Right Alt", 0x60},
    {"A", 0x3C}, {"B", 0x52}, {"C", 0x50}, {"D", 0x3E}, {"E", 0x29}, {"F", 0x3F}, {"G", 0x40}, {"H", 0x41},
    {"I", 0x2E}, {"J", 0x42}, {"K", 0x43}, {"L", 0x44}, {"M", 0x54}, {"N", 0x53}, {"O", 0x2F}, {"P", 0x30},
    {"Q", 0x27}, {"R", 0x2A}, {"S", 0x3D}, {"T", 0x2B}, {"U", 0x2D}, {"V", 0x51}, {"W", 0x28}, {"X", 0x4F},
    {"Y", 0x2C}, {"Z", 0x4E},
    {"1", 0x11}, {"2", 0x12}, {"3", 0x13}, {"4", 0x14}, {"5", 0x15}, {"6", 0x16}, {"7", 0x17}, {"8", 0x18},
    {"9", 0x19}, {"0", 0x1A},
    {"F1", 0x01}, {"F2", 0x02}, {"F3", 0x03}, {"F4", 0x04}, {",", 0x55}, {".", 0x56}, {"/", 0x57},
    {";", 0x45}, {"'", 0x46}, {"Delete", 0x34}, {"Copy", 0x35},
    {"Mouse Left", 0x70}, {"Mouse Middle", 0x71}, {"Mouse Right", 0x72},
};
static const char *key_name(int k) {
    static char buf[16];
    for (const auto &kn : KEYS) if (kn.k == k) return kn.n;
    snprintf(buf, sizeof buf, "Key %02X", k & 0xFF); return buf;
}

struct Pad { SDL_GameController *gc; SDL_JoystickID id; std::string name; };
static Arc *A = nullptr;
static std::string cfg;
static std::vector<Pad> pads;
static int btnmap[SDL_CONTROLLER_BUTTON_MAX];
static int keycount[128];
static bool stick[4], trig[2];                       // left-stick directions (U,D,L,R), triggers (R=left click, L=right click)
static float racc_x, racc_y, tacc_x, tacc_y;
struct Pending { int key, frames; };
static std::vector<Pending> pending;
static const int DIRBTN[4] = { SDL_CONTROLLER_BUTTON_DPAD_UP, SDL_CONTROLLER_BUTTON_DPAD_DOWN,
                               SDL_CONTROLLER_BUTTON_DPAD_LEFT, SDL_CONTROLLER_BUTTON_DPAD_RIGHT };

// ---- on-screen controls: settings, layout and finger tracking ----
struct TouchCfg { int show = 1, mode = 0, size = 1, nbtn = 2, swap = 0; float alpha = 0.55f; int keys[4] = { 0x5F, 0x47, 0x4E, 0x4F }; };
static TouchCfg TC;                                   // mode: 0 joystick, 1 D-pad; size: 0 small, 1 medium, 2 big
static std::string tcfg_path;
static void tc_save() { FILE *f = fopen(tcfg_path.c_str(), "wb"); if (f) { fwrite(&TC, sizeof TC, 1, f); fclose(f); } }
static void tc_load() {
    FILE *f = fopen(tcfg_path.c_str(), "rb"); if (!f) return;
    TouchCfg t; if (fread(&t, sizeof t, 1, f) == 1) {
        bool ok = t.mode >= 0 && t.mode <= 1 && t.size >= 0 && t.size <= 2 && t.nbtn >= 1 && t.nbtn <= 4 && t.alpha >= 0.1f && t.alpha <= 1.f;
        for (int k : t.keys) if (k < 0 || k > 127) ok = false;
        if (ok) TC = t;
    }
    fclose(f);
}
struct Layout { bool valid = false; float sx = 0, sy = 0, sr = 1, bx[4] = {}, by[4] = {}, br = 1; };
static Layout LO;                                     // stick centre/radius, button centres/radius (window points)
struct TFinger { SDL_FingerID id; int ctl; };         // ctl: 0 = stick, 1..4 = action button
static std::vector<TFinger> tfingers;
static bool tdir[4], tbtn[4];
static float tvx, tvy;                                // thumb offset -1..1

bool touch_mode() {
#if defined(__ANDROID__) || (defined(TARGET_OS_IPHONE) && TARGET_OS_IPHONE)
    return true;
#else
    return false;
#endif
}

static void key_ref(int k, bool down) {              // ref-counted so pad + stick + touch can share a key
    if (!A || k < 0 || k > 127) return;
    if (down) { if (keycount[k]++ == 0) arc_key(A, k, 1); }
    else if (keycount[k] > 0 && --keycount[k] == 0) arc_key(A, k, 0);
}
void release_all() {
    for (int k = 0; k < 128; k++) if (keycount[k] > 0) { keycount[k] = 0; if (A) arc_key(A, k, 0); }
    memset(stick, 0, sizeof stick); memset(trig, 0, sizeof trig); pending.clear();
    memset(tdir, 0, sizeof tdir); memset(tbtn, 0, sizeof tbtn); tvx = tvy = 0; tfingers.clear();
}
static void defaults() {
    for (int &v : btnmap) v = -1;
    btnmap[SDL_CONTROLLER_BUTTON_DPAD_UP] = 0x59;    btnmap[SDL_CONTROLLER_BUTTON_DPAD_DOWN] = 0x63;
    btnmap[SDL_CONTROLLER_BUTTON_DPAD_LEFT] = 0x62;  btnmap[SDL_CONTROLLER_BUTTON_DPAD_RIGHT] = 0x64;
    btnmap[SDL_CONTROLLER_BUTTON_A] = 0x47;          /* Return */
    btnmap[SDL_CONTROLLER_BUTTON_B] = 0x5F;          /* Space  */
    btnmap[SDL_CONTROLLER_BUTTON_X] = 0x4E;          /* Z      */
    btnmap[SDL_CONTROLLER_BUTTON_Y] = 0x4F;          /* X      */
    btnmap[SDL_CONTROLLER_BUTTON_LEFTSHOULDER] = 0x4C;   /* Left Shift */
    btnmap[SDL_CONTROLLER_BUTTON_RIGHTSHOULDER] = 0x3B;  /* Left Ctrl  */
    btnmap[SDL_CONTROLLER_BUTTON_START] = 0x00;      /* Escape */
    btnmap[SDL_CONTROLLER_BUTTON_BACK] = 0x26;       /* Tab    */
}
static void save() { if (cfg.empty()) return; FILE *f = fopen(cfg.c_str(), "wb"); if (f) { fwrite(btnmap, sizeof btnmap, 1, f); fclose(f); } }
static void load() {
    FILE *f = fopen(cfg.c_str(), "rb"); if (!f) return;
    int tmp[SDL_CONTROLLER_BUTTON_MAX]; if (fread(tmp, sizeof tmp, 1, f) == 1) memcpy(btnmap, tmp, sizeof tmp);
    fclose(f);
}
void init(Arc *a, const std::string &pref) { A = a; cfg = pref + "pad.cfg"; tcfg_path = pref + "touch.cfg"; defaults(); load(); TC.show = touch_mode() ? 1 : 0; tc_load(); }
void shutdown() { release_all(); for (auto &p : pads) SDL_GameControllerClose(p.gc); pads.clear(); save(); tc_save(); }

static void set_stick(int d, bool on) { if (stick[d] != on) { stick[d] = on; key_ref(btnmap[DIRBTN[d]], on); } }

// ---------------- touch ----------------
static struct { int down = 0; bool in_screen = false; Uint32 t0 = 0; float travel = 0; int maxf = 0; } T;

static void tc_dirs(float dx, float dy) {             // stick/D-pad vector (-1..1) -> arrow keys (8 directions)
    float len = std::sqrt(dx * dx + dy * dy); if (len > 1.f) { dx /= len; dy /= len; }
    tvx = dx; tvy = dy;
    bool want[4] = { dy < -0.35f, dy > 0.35f, dx < -0.35f, dx > 0.35f };
    for (int d = 0; d < 4; d++) if (tdir[d] != want[d]) { tdir[d] = want[d]; key_ref(btnmap[DIRBTN[d]], want[d]); }
}
static void tc_btn(int i, bool down) { if (tbtn[i] != down) { tbtn[i] = down; key_ref(TC.keys[i], down); } }
static int tc_hit(float px, float py) {               // 0 = stick, 1..4 = button, -1 = nothing
    if (!LO.valid || !TC.show) return -1;
    float dx = px - LO.sx, dy = py - LO.sy;
    if (dx * dx + dy * dy <= LO.sr * LO.sr * 1.9f) return 0;
    for (int i = 0; i < TC.nbtn; i++) { dx = px - LO.bx[i]; dy = py - LO.by[i]; if (dx * dx + dy * dy <= LO.br * LO.br * 1.5f) return i + 1; }
    return -1;
}

void handle_event(const SDL_Event &e, int ww, int wh, bool active, const SDL_Rect *sr) {
    switch (e.type) {
    case SDL_CONTROLLERDEVICEADDED: {
        SDL_GameController *gc = SDL_GameControllerOpen(e.cdevice.which);
        if (gc) {
            SDL_JoystickID id = SDL_JoystickInstanceID(SDL_GameControllerGetJoystick(gc));
            for (auto &p : pads) if (p.id == id) return;
            const char *n = SDL_GameControllerName(gc);
            pads.push_back({ gc, id, n ? n : "Controller" });
        }
        break; }
    case SDL_CONTROLLERDEVICEREMOVED:
        for (size_t i = 0; i < pads.size(); i++)
            if (pads[i].id == e.cdevice.which) { SDL_GameControllerClose(pads[i].gc); pads.erase(pads.begin() + (long)i); release_all(); break; }
        break;
    case SDL_CONTROLLERBUTTONDOWN: case SDL_CONTROLLERBUTTONUP:
        if (active && e.cbutton.button < SDL_CONTROLLER_BUTTON_MAX) key_ref(btnmap[e.cbutton.button], e.type == SDL_CONTROLLERBUTTONDOWN);
        break;
    case SDL_FINGERDOWN: {
        if (!touch_mode()) break;
        float px = e.tfinger.x * ww, py = e.tfinger.y * wh;
        int c = active ? tc_hit(px, py) : -1;
        if (c >= 0) {                                   // finger belongs to an on-screen control (multi-touch safe)
            tfingers.push_back({ e.tfinger.fingerId, c });
            if (c == 0) tc_dirs((px - LO.sx) / LO.sr, (py - LO.sy) / LO.sr); else tc_btn(c - 1, true);
            break;
        }
        T.down++;
        if (T.down == 1) {
            T.t0 = SDL_GetTicks(); T.travel = 0; T.maxf = 1; tacc_x = tacc_y = 0;
            T.in_screen = active && sr && px >= sr->x && px < sr->x + sr->w && py >= sr->y && py < sr->y + sr->h;
        } else T.maxf = std::max(T.maxf, T.down);
        break; }
    case SDL_FINGERMOTION: {
        if (!touch_mode()) break;
        bool mine = false;
        for (auto &f : tfingers) if (f.id == e.tfinger.fingerId) {
            mine = true;
            if (f.ctl == 0) tc_dirs((e.tfinger.x * ww - LO.sx) / LO.sr, (e.tfinger.y * wh - LO.sy) / LO.sr);
        }
        if (mine) break;
        if (T.in_screen && T.down == 1 && sr && sr->w > 0 && A) {
            float k = 640.f / (float)sr->w * 1.5f, dx = e.tfinger.dx * ww, dy = e.tfinger.dy * wh;
            T.travel += std::fabs(dx) + std::fabs(dy);
            tacc_x += dx * k; tacc_y += dy * k;
            int ix = (int)tacc_x, iy = (int)tacc_y; tacc_x -= ix; tacc_y -= iy;
            if (ix || iy) arc_mouse_move(A, ix, iy);
        }
        break; }
    case SDL_FINGERUP: {
        if (!touch_mode()) break;
        bool mine = false;
        for (size_t i = 0; i < tfingers.size(); i++) if (tfingers[i].id == e.tfinger.fingerId) {
            mine = true;
            if (tfingers[i].ctl == 0) tc_dirs(0, 0); else tc_btn(tfingers[i].ctl - 1, false);
            tfingers.erase(tfingers.begin() + (long)i); break;
        }
        if (mine) break;
        if (T.down > 0) T.down--;
        if (T.down == 0 && T.in_screen) {
            if (SDL_GetTicks() - T.t0 < 300 && T.travel < 0.02f * (float)ww) {     // tap = left click, 2-finger tap = right click
                int key = T.maxf >= 2 ? 0x72 : 0x70;
                key_ref(key, true); pending.push_back({ key, 4 });
            }
            T.in_screen = false;
        }
        break; }
    default: break;
    }
}

void per_frame(bool active) {
    for (auto &p : pending) if (--p.frames <= 0) { key_ref(p.key, false); p.key = -1; }
    pending.erase(std::remove_if(pending.begin(), pending.end(), [](const Pending &p) { return p.key < 0; }), pending.end());
    if (!active || pads.empty() || !A) return;
    float lx = 0, ly = 0, rx = 0, ry = 0; bool rt = false, lt = false;
    for (auto &p : pads) {
        auto ax = [&](SDL_GameControllerAxis a) { return SDL_GameControllerGetAxis(p.gc, a) / 32767.f; };
        float v;
        if (std::fabs(v = ax(SDL_CONTROLLER_AXIS_LEFTX)) > std::fabs(lx)) lx = v;
        if (std::fabs(v = ax(SDL_CONTROLLER_AXIS_LEFTY)) > std::fabs(ly)) ly = v;
        if (std::fabs(v = ax(SDL_CONTROLLER_AXIS_RIGHTX)) > std::fabs(rx)) rx = v;
        if (std::fabs(v = ax(SDL_CONTROLLER_AXIS_RIGHTY)) > std::fabs(ry)) ry = v;
        if (ax(SDL_CONTROLLER_AXIS_TRIGGERRIGHT) > 0.4f) rt = true;
        if (ax(SDL_CONTROLLER_AXIS_TRIGGERLEFT) > 0.4f) lt = true;
    }
    auto th = [&](int d) { return stick[d] ? 0.35f : 0.55f; };
    set_stick(0, ly < -th(0)); set_stick(1, ly > th(1)); set_stick(2, lx < -th(2)); set_stick(3, lx > th(3));
    if (std::fabs(rx) > 0.2f || std::fabs(ry) > 0.2f) {
        racc_x += rx * std::fabs(rx) * 14.f; racc_y += ry * std::fabs(ry) * 14.f;
        int ix = (int)racc_x, iy = (int)racc_y; racc_x -= ix; racc_y -= iy;
        if (ix || iy) arc_mouse_move(A, ix, iy);
    } else racc_x = racc_y = 0;
    if (rt != trig[0]) { trig[0] = rt; key_ref(0x70, rt); }
    if (lt != trig[1]) { trig[1] = lt; key_ref(0x72, lt); }
}

// ---------------- UI ----------------
void draw_pad_panel() {
    if (!ImGui::CollapsingHeader("Controllers & input", ImGuiTreeNodeFlags_DefaultOpen)) return;
    if (pads.empty()) ImGui::TextWrapped("No controller detected. Pair it in your device's Bluetooth settings, then press any button on it.");
    for (auto &p : pads) ImGui::BulletText("%s", p.name.c_str());
    ImGui::TextDisabled("Left stick = D-pad, right stick = mouse, triggers = mouse buttons. Touch: drag = mouse, tap = click, two-finger tap = right click.");
    if (ImGui::TreeNode("Button mapping")) {
        static const struct { const char *n; int b; } ROWS[] = {
            { "D-pad Up", SDL_CONTROLLER_BUTTON_DPAD_UP }, { "D-pad Down", SDL_CONTROLLER_BUTTON_DPAD_DOWN },
            { "D-pad Left", SDL_CONTROLLER_BUTTON_DPAD_LEFT }, { "D-pad Right", SDL_CONTROLLER_BUTTON_DPAD_RIGHT },
            { "A", SDL_CONTROLLER_BUTTON_A }, { "B", SDL_CONTROLLER_BUTTON_B }, { "X", SDL_CONTROLLER_BUTTON_X },
            { "Y", SDL_CONTROLLER_BUTTON_Y }, { "L1", SDL_CONTROLLER_BUTTON_LEFTSHOULDER },
            { "R1", SDL_CONTROLLER_BUTTON_RIGHTSHOULDER }, { "Start", SDL_CONTROLLER_BUTTON_START },
            { "Back", SDL_CONTROLLER_BUTTON_BACK }, { "L3", SDL_CONTROLLER_BUTTON_LEFTSTICK },
            { "R3", SDL_CONTROLLER_BUTTON_RIGHTSTICK } };
        for (const auto &r : ROWS) {
            ImGui::PushID(r.b);
            ImGui::SetNextItemWidth(ImGui::GetFontSize() * 9);
            if (ImGui::BeginCombo(r.n, key_name(btnmap[r.b]))) {
                for (const auto &kn : KEYS)
                    if (ImGui::Selectable(kn.n, kn.k == btnmap[r.b])) { btnmap[r.b] = kn.k; save(); }
                ImGui::EndCombo();
            }
            ImGui::PopID();
        }
        if (ImGui::Button("Reset to defaults")) { defaults(); save(); }
        ImGui::TreePop();
    }
}

struct Item { const char *l; int k; float u; int kind; };   // kind: 0 key, 1 sticky modifier, 2 mouse hold, 3 hide
static bool st_shift, st_ctrl, st_alt;

static void draw_row(const std::vector<Item> &items, float avail, float sp, float h, bool *open) {
    float U = 0; for (auto &i : items) U += i.u;
    float unit = (avail - sp * (U - 1)) / U;
    for (size_t n = 0; n < items.size(); n++) {
        const Item &it = items[n]; if (n) ImGui::SameLine(0, sp);
        ImVec2 sz(unit * it.u + sp * (it.u - 1), h);
        ImGui::PushID(&it);
        if (it.kind == 1) {
            bool *st = it.k == 0x4C ? &st_shift : it.k == 0x3B ? &st_ctrl : &st_alt;
            if (*st) ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.486f, 0.424f, 1.f, 1.f));
            if (ImGui::Button(it.l, sz)) { *st = !*st; key_ref(it.k, *st); }
            if (*st) ImGui::PopStyleColor();
        } else if (it.kind == 3) {
            if (ImGui::Button(it.l, sz)) *open = false;
        } else {
            ImGui::Button(it.l, sz);
            if (ImGui::IsItemActivated()) key_ref(it.k, true);
            if (ImGui::IsItemDeactivated()) key_ref(it.k, false);
        }
        ImGui::PopID();
    }
}

void draw_virtual_keyboard(bool *open) {
    if (!open || !*open) return;
    ImGuiViewport *vp = ImGui::GetMainViewport();
    float fs = ImGui::GetFontSize(), sp = fs * 0.3f, h = fs * 2.4f, W = vp->WorkSize.x;
    ImGui::SetNextWindowPos(ImVec2(vp->WorkPos.x, vp->WorkPos.y + vp->WorkSize.y), ImGuiCond_Always, ImVec2(0, 1));
    ImGui::SetNextWindowSize(ImVec2(W, 0));
    ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(sp, sp));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(sp, sp));
    ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(2, 2));
    ImGui::Begin("keyboard", nullptr, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize |
                 ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoFocusOnAppearing);
    float avail = W - 2 * sp;
    draw_row({ {"Esc",0x00,1.3f,0},{"1",0x11,1,0},{"2",0x12,1,0},{"3",0x13,1,0},{"4",0x14,1,0},{"5",0x15,1,0},{"6",0x16,1,0},
               {"7",0x17,1,0},{"8",0x18,1,0},{"9",0x19,1,0},{"0",0x1A,1,0},{"Bksp",0x1E,1.6f,0} }, avail, sp, h, open);
    draw_row({ {"Tab",0x26,1.5f,0},{"Q",0x27,1,0},{"W",0x28,1,0},{"E",0x29,1,0},{"R",0x2A,1,0},{"T",0x2B,1,0},{"Y",0x2C,1,0},
               {"U",0x2D,1,0},{"I",0x2E,1,0},{"O",0x2F,1,0},{"P",0x30,1,0} }, avail, sp, h, open);
    draw_row({ {"Ctrl",0x3B,1.6f,1},{"A",0x3C,1,0},{"S",0x3D,1,0},{"D",0x3E,1,0},{"F",0x3F,1,0},{"G",0x40,1,0},{"H",0x41,1,0},
               {"J",0x42,1,0},{"K",0x43,1,0},{"L",0x44,1,0},{"Ret",0x47,1.6f,0} }, avail, sp, h, open);
    draw_row({ {"Shift",0x4C,1.8f,1},{"Z",0x4E,1,0},{"X",0x4F,1,0},{"C",0x50,1,0},{"V",0x51,1,0},{"B",0x52,1,0},{"N",0x53,1,0},
               {"M",0x54,1,0},{",",0x55,1,0},{".",0x56,1,0},{"/",0x57,1,0} }, avail, sp, h, open);
    draw_row({ {"Alt",0x5E,1.3f,1},{"Space",0x5F,4,0},{"<",0x62,1,0},{"^",0x59,1,0},{"v",0x63,1,0},{">",0x64,1,0},
               {"M-L",0x70,1.2f,0},{"M-R",0x72,1.2f,0},{"Hide",0,1.3f,3} }, avail, sp, h, open);
    ImGui::End();
    ImGui::PopStyleVar(3);
}

void draw_touch_controls(const SDL_Rect *sr, bool active) {
    LO.valid = false;
    if (!touch_mode() || !TC.show || !active || !sr || sr->w < 100 || sr->h < 80) return;
    if (ImGui::IsPopupOpen(nullptr, ImGuiPopupFlags_AnyPopupId | ImGuiPopupFlags_AnyPopupLevel)) return;
    float fs = ImGui::GetFontSize(), sf = TC.size == 0 ? 0.75f : TC.size == 2 ? 1.4f : 1.0f, margin = fs * 0.8f;
    float R = std::min(fs * 3.4f * sf, sr->h * 0.3f), r = std::min(fs * 2.0f * sf, sr->h * 0.16f);
    float need = 2 * R + 4.5f * r + 3 * margin;
    if (need > sr->w) { float k = sr->w / need; R *= k; r *= k; }
    float left = sr->x + margin, right = sr->x + sr->w - margin, bottom = sr->y + sr->h - margin, d = r * 1.25f;
    bool sw = TC.swap != 0;
    LO.sx = sw ? right - R : left + R; LO.sy = bottom - R; LO.sr = R; LO.br = r;
    float cx = sw ? left + r + d : right - r - d, cy = bottom - r - d;
    if (TC.nbtn == 1) { cx = sw ? left + r : right - r; cy = bottom - r; }
    const float ox[4] = { 0, d, -d, 0 }, oy[4] = { TC.nbtn == 1 ? 0.f : d, 0, 0, -d };   // A bottom, B right, X left, Y top
    for (int i = 0; i < 4; i++) { LO.bx[i] = cx + ox[i]; LO.by[i] = cy + oy[i]; }
    LO.valid = true;

    ImDrawList *dl = ImGui::GetForegroundDrawList();
    auto C = [&](int rr, int g, int b, float f) { return IM_COL32(rr, g, b, (int)(255.f * TC.alpha * f)); };
    bool any = tdir[0] || tdir[1] || tdir[2] || tdir[3];
    if (TC.mode == 0) {                                  // analogue-style joystick
        dl->AddCircleFilled(ImVec2(LO.sx, LO.sy), R, C(255, 255, 255, 0.22f), 48);
        dl->AddCircle(ImVec2(LO.sx, LO.sy), R, C(255, 255, 255, 0.6f), 48, 3.f);
        dl->AddCircleFilled(ImVec2(LO.sx + tvx * R * 0.58f, LO.sy + tvy * R * 0.58f), R * 0.42f, C(124, 108, 255, any ? 1.f : 0.75f), 32);
    } else {                                             // D-pad cross
        float w = R * 0.62f, hw = w / 2;
        ImU32 base = C(255, 255, 255, 0.22f), on = C(124, 108, 255, 1.f);
        dl->AddRectFilled(ImVec2(LO.sx - R, LO.sy - hw), ImVec2(LO.sx + R, LO.sy + hw), base, hw * 0.5f);
        dl->AddRectFilled(ImVec2(LO.sx - hw, LO.sy - R), ImVec2(LO.sx + hw, LO.sy + R), base, hw * 0.5f);
        if (tdir[0]) dl->AddRectFilled(ImVec2(LO.sx - hw, LO.sy - R), ImVec2(LO.sx + hw, LO.sy - hw * 0.2f), on, hw * 0.5f);
        if (tdir[1]) dl->AddRectFilled(ImVec2(LO.sx - hw, LO.sy + hw * 0.2f), ImVec2(LO.sx + hw, LO.sy + R), on, hw * 0.5f);
        if (tdir[2]) dl->AddRectFilled(ImVec2(LO.sx - R, LO.sy - hw), ImVec2(LO.sx - hw * 0.2f, LO.sy + hw), on, hw * 0.5f);
        if (tdir[3]) dl->AddRectFilled(ImVec2(LO.sx + hw * 0.2f, LO.sy - hw), ImVec2(LO.sx + R, LO.sy + hw), on, hw * 0.5f);
        dl->AddCircle(ImVec2(LO.sx, LO.sy), R, C(255, 255, 255, 0.35f), 48, 2.f);
    }
    for (int i = 0; i < TC.nbtn; i++) {
        ImVec2 c(LO.bx[i], LO.by[i]);
        dl->AddCircleFilled(c, r, tbtn[i] ? C(124, 108, 255, 1.f) : C(255, 255, 255, 0.22f), 32);
        dl->AddCircle(c, r, C(255, 255, 255, 0.6f), 32, 3.f);
        const char *lab = TC.keys[i] == 0x5F ? "Jump" : key_name(TC.keys[i]);
        ImVec2 ts = ImGui::CalcTextSize(lab);
        dl->AddText(ImVec2(c.x - ts.x / 2, c.y - ts.y / 2), C(255, 255, 255, 1.f), lab);
    }
}

void draw_touch_panel() {
    if (!touch_mode()) return;
    if (!ImGui::CollapsingHeader("On-screen controls", ImGuiTreeNodeFlags_DefaultOpen)) return;
    bool ch = false;
    bool show = TC.show != 0; if (ImGui::Checkbox("Show on-screen controls", &show)) { TC.show = show; ch = true; }
    ImGui::TextDisabled("Movement");
    if (ImGui::RadioButton("Joystick", TC.mode == 0)) { TC.mode = 0; ch = true; } ImGui::SameLine();
    if (ImGui::RadioButton("D-pad", TC.mode == 1)) { TC.mode = 1; ch = true; }
    ImGui::TextDisabled("Size");
    if (ImGui::RadioButton("Small", TC.size == 0)) { TC.size = 0; ch = true; } ImGui::SameLine();
    if (ImGui::RadioButton("Medium", TC.size == 1)) { TC.size = 1; ch = true; } ImGui::SameLine();
    if (ImGui::RadioButton("Big", TC.size == 2)) { TC.size = 2; ch = true; }
    ImGui::TextDisabled("Action buttons");
    for (int n = 1; n <= 4; n++) {
        char lb[8]; snprintf(lb, sizeof lb, "%d", n);
        if (n > 1) ImGui::SameLine();
        if (ImGui::RadioButton(lb, TC.nbtn == n)) { TC.nbtn = n; ch = true; }
    }
    bool sw = TC.swap != 0; if (ImGui::Checkbox("Left-handed (swap sides)", &sw)) { TC.swap = sw; ch = true; }
    if (ImGui::SliderFloat("Opacity", &TC.alpha, 0.15f, 1.f, "%.2f")) ch = true;
    for (int i = 0; i < TC.nbtn; i++) {
        char lb[24]; snprintf(lb, sizeof lb, "Button %d key", i + 1);
        ImGui::PushID(1000 + i); ImGui::SetNextItemWidth(ImGui::GetFontSize() * 9);
        if (ImGui::BeginCombo(lb, key_name(TC.keys[i]))) {
            for (const auto &kn : KEYS) if (kn.k >= 0 && ImGui::Selectable(kn.n, kn.k == TC.keys[i])) { TC.keys[i] = kn.k; ch = true; }
            ImGui::EndCombo();
        }
        ImGui::PopID();
    }
    ImGui::TextDisabled("Button 1 defaults to Jump (Space). The stick/D-pad sends the arrow keys.");
    if (ch) tc_save();
}

} // namespace input

#include "platform.h"
#include <SDL.h>
#include <mutex>
#include <utility>
#include <vector>
#ifdef __ANDROID__
#include <jni.h>
#endif

namespace platform {
static std::mutex mtx;
static std::vector<std::pair<std::string, int>> queue;

bool poll_picked(std::string &path, int &kind) {
    std::lock_guard<std::mutex> l(mtx);
    if (queue.empty()) return false;
    path = queue.front().first; kind = queue.front().second; queue.erase(queue.begin()); return true;
}

#ifdef __ANDROID__
bool native_picker() { return true; }
void pick(int kind) {
    JNIEnv *env = (JNIEnv *)SDL_AndroidGetJNIEnv();
    jobject act = (jobject)SDL_AndroidGetActivity();
    if (!env || !act) return;
    jclass cls = env->GetObjectClass(act);
    jmethodID m = env->GetMethodID(cls, "pickFile", "(I)V");
    if (m) env->CallVoidMethod(act, m, (jint)kind);
    env->DeleteLocalRef(cls); env->DeleteLocalRef(act);
}
extern "C" JNIEXPORT void JNICALL Java_com_archimedes_emu_ArcActivity_nativeFilePicked(JNIEnv *env, jclass, jstring path, jint kind) {
    const char *s = env->GetStringUTFChars(path, nullptr);
    { std::lock_guard<std::mutex> l(mtx); queue.push_back({ s, (int)kind }); }
    env->ReleaseStringUTFChars(path, s);
}
#else
bool native_picker() { return false; }
void pick(int) {}
#endif
} // namespace platform

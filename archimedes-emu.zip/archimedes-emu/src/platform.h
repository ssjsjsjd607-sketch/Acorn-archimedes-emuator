#pragma once
#include <string>
// Native file picking. On Android this opens the system document picker (Storage Access Framework);
// the chosen file is copied into app storage and reported back through poll_picked().
namespace platform {
bool native_picker();                       // true if pick() is available (Android)
void pick(int kind);                        // kind 0 = ROM, 1..3 = floppy A..C
bool poll_picked(std::string &path, int &kind);
}

#ifndef ARC_EMU_H
#define ARC_EMU_H
#include <stdint.h>
#include <stdio.h>
#ifdef __cplusplus
extern "C" {
#endif

#define ARC_NDRIVES 3            /* floppy A, B, C  (= :0 :1 :2) */
#define ARC_SND_RATE 44100
#define ARC_SND_FRAMES 882          /* stereo samples generated per 20 ms frame */
#define ARC_MAX_W 1024
#define ARC_MAX_H 768

enum { M_USR, M_FIQ, M_IRQ, M_SVC };

typedef struct {
    uint8_t *data; uint32_t size; FILE *fp; char path[512];
    int inserted, writable, protect;           /* writable = file allows it, protect = user toggle */
    int tracks, sides, spt, ssize, first;      /* geometry; first = first sector number */
} Floppy;

typedef struct Arc {
    /* ---- ARM2 (26-bit) ---- */
    uint32_t r[16], pc, npc, bank[4][7], shared[5];
    int N, Z, C, V, I, F, mode, abort, irq, fiq;
    uint64_t cycles;
    /* ---- memory ---- */
    uint8_t *rom, *ram; uint32_t rom_size, ram_size; int rom_high;
    /* ---- MEMC ---- */
    int pagesize;                               /* 0..3 = 4K/8K/16K/32K */
    int16_t lpn_ppn[8192], ppn_lpn[128]; uint8_t ppn_ppl[128];
    uint32_t vinit, vstart, vend, cinit; int vdma;
    /* ---- VIDC ---- */
    uint16_t pal[16], cpal[4], vreg[16]; uint32_t vctl;
    /* ---- IOC ---- */
    uint8_t irqA_edge, irqA_mask, irqB_mask, fiq_mask;
    uint16_t t_latch[4], t_out[4]; int32_t t_count[4]; uint32_t t_acc;
    /* ---- I2C CMOS (PCF8583) ---- */
    int i2c_scl, i2c_sdam, i2c_sdas, i2c_mode, i2c_next, i2c_nbit, i2c_ack, i2c_ackout;
    uint8_t i2c_shift, i2c_ptr, i2c_tx, cmos[256];
    /* ---- keyboard / mouse (KART) ---- */
    uint8_t kart_rx, kq[64]; int kart_full, kb_state, kb_wait, kq_h, kq_n, mdx, mdy;
    /* ---- WD1772 floppy controller ---- */
    int fdc_track, fdc_sector, fdc_data, fdc_status, fdc_irq, fdc_drq, fdc_state, fdc_type1;
    int fdc_pos, fdc_len, fdc_multi, fdc_off, fdc_hl, fdc_dir, fdc_drive;
    uint8_t fdc_buf[1024], latch_a; int latch_set, head_track[ARC_NDRIVES];
    int fdd_activity;                           /* UI LED, decays each frame */
    Floppy fdd[ARC_NDRIVES];
    /* ---- sound (VIDC1a channels + MEMC sound DMA) ---- */
    int sdma, s_valid, s_running, snd_irq, snd_n; uint32_t s_nstart, s_nend, s_cur, s_end;
    uint16_t vfreq; uint8_t sbal[8]; int16_t shold[8]; float snd_acc; int16_t snd_out[ARC_SND_FRAMES * 2];
    /* ---- diagnostics ---- */
    int unk_count; uint32_t unk_last; int trace;
    int unk_n; uint32_t unk_log[8], unk_wr;                       /* first few unmapped I/O accesses (R/W) */
    uint32_t c_irq, c_fiq, c_swi, c_dabort, c_pabort, c_undef, c_map, c_ctl, c_vidc, c_kbtx, last_swi, frames;
    uint32_t pc_samp[8]; int pc_samp_n;                           /* PC sampled once per frame: shows where a hang is */
    int dbg_video, dbg_bpp; uint32_t dbg_base;                    /* debug: show raw RAM as the screen */
} Arc;

int  arc_init(Arc *a, uint32_t ram_size);
/* RISC OS 3.1x ships as four byte-lane chips (IC24..IC27). Builds the 32-bit-wide image (4*n bytes) in `out`;
 * returns 1 if the lane order had to be reversed (auto-detected from the ARM vector table), else 0. */
int  arc_rom_interleave(const uint8_t *const p[4], uint32_t n, uint8_t *out);
int  arc_load_rom(Arc *a, const uint8_t *rom, uint32_t size);   /* resets the machine */
void arc_free(Arc *a);
void arc_reset(Arc *a);
void arc_frame(Arc *a);                                         /* one 20 ms (50 Hz) frame */
void arc_video_size(const Arc *a, int *w, int *h);
void arc_report(const Arc *a, char *buf, size_t cap);          /* human-readable machine state for bug reports */
void arc_render(const Arc *a, uint32_t *argb, int w, int h);
int  arc_disk_insert(Arc *a, int drive, const char *path);     /* 0 ok, <0 error */
void arc_disk_eject(Arc *a, int drive);
void arc_key(Arc *a, int keynum, int down);                     /* Archimedes key numbers */
void arc_mouse_move(Arc *a, int dx, int dy);
/* Save states: CPU + all hardware + RAM. Disk images are referenced by path (their writes already live in the files). */
int  arc_state_save(Arc *a, const char *path);     /* 0 ok, -1 I/O error */
int  arc_state_load(Arc *a, const char *path);     /* 0 ok, 1 ok but a disk image is missing, -1 no file, -2 incompatible, -3 different ROM */
void arc_cmos_load(Arc *a, const char *path);
void arc_cmos_save(const Arc *a, const char *path);

#ifdef __cplusplus
}
#endif
#endif

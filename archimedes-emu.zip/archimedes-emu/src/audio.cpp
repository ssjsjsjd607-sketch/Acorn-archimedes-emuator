#include "audio.h"
#include "arc.h"
#include <SDL.h>
#include <vector>

namespace audio {
static SDL_AudioDeviceID dev = 0;
static float vol = 0.8f;
static bool mute = false, primed = false;

bool init() {
    SDL_AudioSpec want, have;
    SDL_zero(want); SDL_zero(have);
    want.freq = ARC_SND_RATE; want.format = AUDIO_S16SYS; want.channels = 2; want.samples = 1024; want.callback = nullptr;
    dev = SDL_OpenAudioDevice(nullptr, 0, &want, &have, 0);     // SDL converts if the device runs at another rate
    if (!dev) return false;
    SDL_PauseAudioDevice(dev, 0);
    return true;
}
void shutdown() { if (dev) SDL_CloseAudioDevice(dev); dev = 0; }
void clear() { if (dev) SDL_ClearQueuedAudio(dev); primed = false; }
void set_volume(float v) { vol = v < 0 ? 0 : v > 1 ? 1 : v; }
float volume() { return vol; }
void set_mute(bool m) { mute = m; }
bool muted() { return mute; }

void push(const int16_t *s, int frames) {
    if (!dev || frames <= 0) return;
    static std::vector<int16_t> tmp;
    if (!primed) {                                               // ~40 ms head start so timing jitter doesn't crackle
        tmp.assign((size_t)frames * 2 * 2, 0);
        SDL_QueueAudio(dev, tmp.data(), (Uint32)(tmp.size() * 2)); primed = true;
    }
    if (SDL_GetQueuedAudioSize(dev) > (Uint32)(ARC_SND_RATE * 4 * 12 / 100)) return;   // cap latency at ~120 ms
    float g = mute ? 0.f : vol * vol;
    tmp.resize((size_t)frames * 2);
    for (int i = 0; i < frames * 2; i++) tmp[(size_t)i] = (int16_t)(s[i] * g);
    SDL_QueueAudio(dev, tmp.data(), (Uint32)frames * 4);
}
} // namespace audio

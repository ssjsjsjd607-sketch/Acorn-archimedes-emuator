#!/usr/bin/env bash
# Usage: scripts/fetch_deps.sh [imgui]   ("imgui" = skip SDL, use the system SDL2)
set -euo pipefail
cd "$(dirname "$0")/.."
SDL_VER=2.30.8; IMGUI_TAG=v1.91.5
mkdir -p third_party
if [ ! -f third_party/imgui/imgui.cpp ]; then
  curl -fsSL "https://github.com/ocornut/imgui/archive/refs/tags/${IMGUI_TAG}.tar.gz" | tar xz -C third_party
  mv "third_party/imgui-${IMGUI_TAG#v}" third_party/imgui
fi
if [ "${1:-}" != "imgui" ]; then
  if [ ! -f third_party/SDL2/CMakeLists.txt ]; then
    curl -fsSL "https://github.com/libsdl-org/SDL/releases/download/release-${SDL_VER}/SDL2-${SDL_VER}.tar.gz" | tar xz -C third_party
    mv "third_party/SDL2-${SDL_VER}" third_party/SDL2
  fi
  JAVA=third_party/SDL2/android-project/app/src/main/java/org/libsdl/app
  if [ -d "$JAVA" ]; then mkdir -p android/app/src/main/java/org/libsdl/app; cp "$JAVA"/*.java android/app/src/main/java/org/libsdl/app/; fi
fi
echo "dependencies ready"

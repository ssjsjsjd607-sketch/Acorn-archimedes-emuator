#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p dist
sudo apt-get update
sudo apt-get install -y cmake pkg-config libasound2-dev libpulse-dev libx11-dev libxext-dev libxrandr-dev libxcursor-dev libxi-dev libxfixes-dev libxss-dev libxkbcommon-dev libgl1-mesa-dev libgles2-mesa-dev libegl1-mesa-dev libudev-dev libdbus-1-dev
bash scripts/fetch_deps.sh
cmake -B build -DARC_STATIC_SDL=ON -DSDL_WAYLAND=OFF -DSDL_KMSDRM=OFF
cmake --build build -j4
ctest --test-dir build --output-on-failure
tar czf dist/archimedes-linux-x86_64.tar.gz -C build archimedes

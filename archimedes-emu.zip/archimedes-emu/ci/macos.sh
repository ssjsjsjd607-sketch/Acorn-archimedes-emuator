#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p dist
bash scripts/fetch_deps.sh
cmake -B build -DARC_STATIC_SDL=ON -DCMAKE_OSX_ARCHITECTURES="arm64;x86_64" -DCMAKE_OSX_DEPLOYMENT_TARGET=11.0
cmake --build build -j4
ctest --test-dir build --output-on-failure
codesign --force --deep -s - build/Archimedes.app
ditto -c -k --keepParent build/Archimedes.app dist/Archimedes-macos.zip

#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p dist
bash scripts/fetch_deps.sh
gradle -p android assembleDebug --no-daemon
cp android/app/build/outputs/apk/debug/*.apk dist/Archimedes-android.apk

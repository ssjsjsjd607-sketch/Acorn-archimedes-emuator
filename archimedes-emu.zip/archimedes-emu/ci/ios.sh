#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p dist
bash scripts/fetch_deps.sh
cmake -S . -B build-ios -G Xcode -DCMAKE_SYSTEM_NAME=iOS -DCMAKE_OSX_SYSROOT=iphoneos -DCMAKE_OSX_ARCHITECTURES=arm64 -DCMAKE_OSX_DEPLOYMENT_TARGET=13.0
xcodebuild -project build-ios/archimedes_emu.xcodeproj -scheme archimedes -configuration Release -sdk iphoneos -destination 'generic/platform=iOS' CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY="" build
APP=$(find build-ios -name "archimedes.app" -type d | head -1)
rm -rf Payload && mkdir Payload && cp -r "$APP" Payload/
zip -qr dist/archimedes-ios-unsigned.ipa Payload

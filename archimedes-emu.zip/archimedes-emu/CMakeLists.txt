cmake_minimum_required(VERSION 3.18)
project(archimedes_emu C CXX)
set(CMAKE_C_STANDARD 99)
set(CMAKE_CXX_STANDARD 17)
if(NOT CMAKE_BUILD_TYPE AND NOT CMAKE_CONFIGURATION_TYPES)
  set(CMAKE_BUILD_TYPE Release)
endif()
option(ARC_STATIC_SDL "Link the bundled SDL2 statically (self-contained Linux/macOS builds)" OFF)

set(IMGUI_DIR ${CMAKE_SOURCE_DIR}/third_party/imgui)
if(NOT EXISTS ${IMGUI_DIR}/imgui.cpp)
  message(FATAL_ERROR "Dear ImGui missing: run scripts/fetch_deps.sh first")
endif()

# SDL2: bundled copy (iOS / CI / static builds) or the system one (Linux / macOS dev)
if(EXISTS ${CMAKE_SOURCE_DIR}/third_party/SDL2/CMakeLists.txt)
  set(SDL_TEST OFF CACHE BOOL "" FORCE)
  if(CMAKE_SYSTEM_NAME STREQUAL "iOS" OR ARC_STATIC_SDL)
    set(SDL_SHARED OFF CACHE BOOL "" FORCE)
    set(SDL_STATIC ON CACHE BOOL "" FORCE)
  else()
    set(SDL_SHARED ON CACHE BOOL "" FORCE)
    set(SDL_STATIC OFF CACHE BOOL "" FORCE)
  endif()
  add_subdirectory(third_party/SDL2 EXCLUDE_FROM_ALL)
  foreach(t SDL2::SDL2 SDL2::SDL2-static SDL2-static SDL2)
    if(NOT SDL_TARGET AND TARGET ${t})
      set(SDL_TARGET ${t})
    endif()
  endforeach()
  foreach(t SDL2::SDL2main SDL2main)
    if(NOT SDL_MAIN_TARGET AND TARGET ${t})
      set(SDL_MAIN_TARGET ${t})
    endif()
  endforeach()
else()
  find_package(SDL2 REQUIRED)
  if(TARGET SDL2::SDL2)
    set(SDL_TARGET SDL2::SDL2)
  else()
    add_library(sdl2_iface INTERFACE)
    target_include_directories(sdl2_iface INTERFACE ${SDL2_INCLUDE_DIRS})
    target_link_libraries(sdl2_iface INTERFACE ${SDL2_LIBRARIES})
    set(SDL_TARGET sdl2_iface)
  endif()
endif()

add_library(imgui STATIC
  ${IMGUI_DIR}/imgui.cpp ${IMGUI_DIR}/imgui_draw.cpp ${IMGUI_DIR}/imgui_tables.cpp ${IMGUI_DIR}/imgui_widgets.cpp
  ${IMGUI_DIR}/backends/imgui_impl_sdl2.cpp ${IMGUI_DIR}/backends/imgui_impl_sdlrenderer2.cpp)
target_include_directories(imgui PUBLIC ${IMGUI_DIR} ${IMGUI_DIR}/backends)
target_link_libraries(imgui PUBLIC ${SDL_TARGET})

add_library(arc STATIC src/arc.c)
target_include_directories(arc PUBLIC src)

add_executable(archimedes src/main.cpp src/input.cpp src/platform.cpp src/audio.cpp)
target_link_libraries(archimedes arc imgui ${SDL_MAIN_TARGET} ${SDL_TARGET})   # SDL2main: provides UIApplicationMain on iOS

if(CMAKE_SYSTEM_NAME STREQUAL "iOS")
  set_target_properties(archimedes PROPERTIES MACOSX_BUNDLE ON
    MACOSX_BUNDLE_INFO_PLIST ${CMAKE_SOURCE_DIR}/ios/Info.plist
    XCODE_ATTRIBUTE_PRODUCT_BUNDLE_IDENTIFIER com.archimedes.emu)
elseif(APPLE)
  set_target_properties(archimedes PROPERTIES OUTPUT_NAME Archimedes MACOSX_BUNDLE ON
    MACOSX_BUNDLE_INFO_PLIST ${CMAKE_SOURCE_DIR}/macos/Info.plist)   # -> Archimedes.app
endif()

if(NOT CMAKE_SYSTEM_NAME STREQUAL "iOS")
  enable_testing()
  add_executable(test_core tests/test_core.c)
  target_include_directories(test_core PRIVATE src)
  add_test(NAME core COMMAND test_core)
endif()

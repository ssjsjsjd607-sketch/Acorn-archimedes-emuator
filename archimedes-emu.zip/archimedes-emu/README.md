# Archimedes emulator

ARM2 + MEMC + IOC + VIDC + WD1772 floppy + CMOS + keyboard/mouse in portable C99 (`src/arc.c`),
with an SDL2 + Dear ImGui front end for **Android, iOS, Linux and macOS**.

## Get the Android APK from your phone (no computer needed)
1. Create a free GitHub account, make a new **private** repository.
2. Unzip this project on your phone and upload everything (keep the folder structure, including the
   hidden `.github` folder) with GitHub's "Add file -> Upload files", or use a Git app (e.g. Termux `git`).
3. Open the repo's **Actions** tab -> *Build* -> wait ~10 minutes (or tap *Run workflow*).
4. Open the finished run, download **archimedes-android-apk**, unzip, tap the `.apk`, allow
   "install unknown apps" for your browser/files app. It's debug-signed, so it installs as-is.
The same workflow also builds Linux, macOS and an **unsigned** iOS .ipa (experimental; sideload with AltStore/Sideloadly).

## Bluetooth controllers
Pair the controller in Android *Settings -> Bluetooth* (put it in pairing mode first), then open the app and press
a button. It appears under **Controllers & input**. SDL handles Xbox, PlayStation, Switch Pro and most generic
gamepads. Default mapping: D-pad / left stick = arrow keys, A = Return, B = Space, X = Z, Y = X, L1 = Shift,
R1 = Ctrl, Start = Esc, Back = Tab, right stick = mouse, triggers = mouse buttons. Every button is remappable
(saved in `pad.cfg`). Bluetooth keyboards work as normal keyboards. Controllers that SDL doesn't recognise as a
gamepad aren't picked up yet.

## ROM
RISC OS 3.1x ROMs are usually four files, **IC24.ROM ... IC27.ROM** (512 KB each). Choose **Import ROM** and select all four
(on Android the picker lets you tick several; on desktop import them one at a time or drag them all onto the window).
The app combines them into one 2 MB image and works out the layout itself (byte order, or four contiguous pieces) by looking for
the ARM vector table and readable message text. The chips are remembered, so the ROM is rebuilt at every start. A single full ROM file also works.

## If the screen stays black
Power on, tap **Menu**, open **Diagnostics** and tap **Copy report** - it copies the machine state (first and last instructions executed, PC history, aborts,
SWI count, memory-controller and video registers, unmapped I/O) so you can paste it into a bug report. "Show raw RAM as
the screen" lets you look at memory directly (try 8 bpp and move the offset) to see whether RISC OS is drawing
somewhere other than where the emulator is looking.

## Display
Starts **fullscreen** and, when you power on, switches to a **full-screen game view** (just the picture, your on-screen
controls and a small Menu / Keys / Pause / Save / Load bar). Tap **Menu** (or press Android Back, or F10 on desktop) to
return to the panels. F11 toggles the window's fullscreen; both options are under *Display* and are remembered.

## On-screen controls (phones)
A multi-touch overlay on the screen: a **joystick** (all 8 directions) or a **D-pad**, plus 1-4 action buttons.
Button 1 is **Jump** (Space) by default; every button's key is configurable. Choose joystick/D-pad, **Small/Medium/Big**,
opacity and left-handed layout under *On-screen controls*. You can move and jump at the same time. The stick sends the
arrow keys (it follows the D-pad binding in the controller mapping).

## Save states
Four slots under *Save states*: **Save state** (while powered on) and **Load state**. A state holds the whole
machine (CPU, hardware, RAM) and remembers which disk images were in A/B/C. States only load with the same ROM they
were saved with. Floppy writes already live in the disk files, so they are not rolled back.

## Touch
Drag on the screen = mouse, tap = left click, two-finger tap = right click, **Keys** = on-screen keyboard
(Shift/Ctrl/Alt are sticky; M-L / M-R hold a mouse button).

## Files
**Import ROM** and **Insert...** open Android's file picker. Files are copied into app storage, so floppy saves
stay in the app's copy (re-picking a disk makes a new copy rather than overwriting).

## Linux, macOS and iOS
Built by the same Actions workflow (or run **ports-from-zip.yml** manually). Everything lands on the Releases page.
- **Linux** (`archimedes-linux-x86_64.tar.gz`): one self-contained binary (SDL is linked in; X11/Wayland, audio and
  controllers are found at run time). Needs a PC with glibc 2.35+ (Ubuntu 22.04 or newer). `tar xzf ... && ./archimedes`.
- **macOS** (`Archimedes-macos.zip`): universal `Archimedes.app` (Apple Silicon + Intel), ad-hoc signed. The first time,
  right-click -> Open (or run `xattr -cr Archimedes.app`) so Gatekeeper lets it start.
- **iOS** (`archimedes-ios-unsigned.ipa`, experimental): unsigned, so it must be sideloaded (AltStore / Sideloadly / TrollStore).
  Copy your ROM and disk images into the *Archimedes* folder in the Files app (On My iPhone), then use Import ROM / Insert.
  Touch controls, on-screen keyboard and Bluetooth controllers work the same as on Android.
- Desktop: drag-and-drop a ROM or disk image onto the window; click the screen to capture the mouse, F12 releases it.

## Desktop build
    bash scripts/fetch_deps.sh imgui && cmake -B build && cmake --build build && ctest --test-dir build
    ./build/archimedes      # ARC_TRACE=1 logs unmapped I/O

## Status: UNTESTED AGAINST A REAL ROM, AND THE UI/ANDROID BUILD HAS NEVER BEEN COMPILED
Verified headless (`tests/test_core.c`): ARM2 core, MEMC mapping/aborts, IOC timers/IRQs, keyboard handshake,
I2C CMOS, floppy read/write. Input code was syntax-checked against stub headers only.
If the Actions build fails, open the failed step's log and send me the first error.

Places most likely to need fixing when a ROM misbehaves (written from memory of the hardware docs):
`LATCH_A_OFF` and side-select polarity, MEMC video DMA scaling, VIDC horizontal timing / pointer position,
IOC IRQ/FIQ bits for the FDC, keyboard protocol details, floating-bus value for absent expansion cards.
Sound: VIDC 8-channel log samples, stereo positions and MEMC sound-DMA double-buffering are modelled (44.1 kHz out; volume and mute in the UI). Frame/channel timing and DMA register scaling are best guesses (`snd_gen`).
Not implemented: ARM3/ARM250, hard discs, podules, disc-changed line, FDC read/write-track.

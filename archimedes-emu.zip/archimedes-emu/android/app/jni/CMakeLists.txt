cmake_minimum_required(VERSION 3.18)
project(archimedes_android C CXX)
set(CMAKE_C_STANDARD 99)
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_C_FLAGS "${CMAKE_C_FLAGS} -O2")
set(CMAKE_CXX_FLAGS "${CMAKE_CXX_FLAGS} -O2")
set(ROOT ${CMAKE_CURRENT_SOURCE_DIR}/../../..)
set(IMGUI ${ROOT}/third_party/imgui)

set(SDL_TEST OFF CACHE BOOL "" FORCE)
set(SDL_STATIC OFF CACHE BOOL "" FORCE)
set(SDL_SHARED ON CACHE BOOL "" FORCE)
add_subdirectory(${ROOT}/third_party/SDL2 SDL2-build)

add_library(main SHARED
  ${ROOT}/src/main.cpp ${ROOT}/src/input.cpp ${ROOT}/src/platform.cpp ${ROOT}/src/audio.cpp ${ROOT}/src/arc.c
  ${IMGUI}/imgui.cpp ${IMGUI}/imgui_draw.cpp ${IMGUI}/imgui_tables.cpp ${IMGUI}/imgui_widgets.cpp
  ${IMGUI}/backends/imgui_impl_sdl2.cpp ${IMGUI}/backends/imgui_impl_sdlrenderer2.cpp)
target_include_directories(main PRIVATE ${ROOT}/src ${IMGUI} ${IMGUI}/backends)
target_link_libraries(main SDL2::SDL2)

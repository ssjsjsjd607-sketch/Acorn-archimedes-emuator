package com.archimedes.emu;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import org.libsdl.app.SDLActivity;

/** SDL activity + system file picker (ROM and floppy images are copied into app storage). */
public class ArcActivity extends SDLActivity {
    private static native void nativeFilePicked(String path, int kind);

    /** Called from native code. kind 0 = ROM, 1..3 = floppy A..C. */
    public void pickFile(final int kind) {
        runOnUiThread(() -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            startActivityForResult(i, 4000 + kind);
        });
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req >= 4000 && req < 4010 && res == RESULT_OK && data != null && data.getData() != null) {
            final int kind = req - 4000;
            final Uri uri = data.getData();
            new Thread(() -> {
                try {
                    String path = copyToPrivate(uri, kind == 0);
                    if (path != null) nativeFilePicked(path, kind);
                } catch (Exception e) { /* picker cancelled or unreadable */ }
            }).start();
        }
    }

    private String copyToPrivate(Uri uri, boolean overwrite) throws IOException {
        String name = "image.bin";
        try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0 && c.getString(idx) != null) name = c.getString(idx).replaceAll("[/\\\\]", "_");
            }
        }
        File dir = new File(getFilesDir(), "imports");
        dir.mkdirs();
        File out = new File(dir, name);
        for (int n = 1; !overwrite && out.exists(); n++) out = new File(dir, n + "_" + name); // never clobber a disk with saved games
        try (InputStream in = getContentResolver().openInputStream(uri); FileOutputStream os = new FileOutputStream(out)) {
            if (in == null) return null;
            byte[] buf = new byte[65536];
            int r;
            while ((r = in.read(buf)) > 0) os.write(buf, 0, r);
        }
        return out.getAbsolutePath();
    }
}

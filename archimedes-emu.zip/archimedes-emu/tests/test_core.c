/* Headless checks of the hardware model. Build: gcc -std=c99 -Isrc tests/test_core.c -o /tmp/t && /tmp/t */
#include "../src/arc.c"
#include <assert.h>
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } else passes++; } while (0)
static int fails, passes;

static void i2c_start(Arc*a){ i2c_update(a,1,1); i2c_update(a,1,0); i2c_update(a,0,0); }
static void i2c_stop(Arc*a){ i2c_update(a,0,0); i2c_update(a,1,0); i2c_update(a,1,1); }
static int i2c_wbyte(Arc*a,uint8_t b){            /* returns 1 if slave ACKed */
    int i, ack; for(i=7;i>=0;i--){ int bit=(b>>i)&1; i2c_update(a,0,bit); i2c_update(a,1,bit); i2c_update(a,0,bit); }
    i2c_update(a,0,1); i2c_update(a,1,1); ack = !((a->i2c_sdam & a->i2c_sdas)); i2c_update(a,0,1); return ack; }
static uint8_t i2c_rbyte(Arc*a,int ack){
    int i; uint8_t v=0; for(i=0;i<8;i++){ i2c_update(a,0,1); i2c_update(a,1,1); v=(v<<1)|(a->i2c_sdam&a->i2c_sdas); i2c_update(a,0,1); }
    i2c_update(a,0,ack?0:1); i2c_update(a,1,ack?0:1); i2c_update(a,0,ack?0:1); i2c_update(a,0,1); return v; }

int main(void){
    Arc *a = calloc(1, sizeof *a); uint32_t prog[] = {0xE3A00402,0xE3A01000,0xE4C01001,0xE2811001,0xEAFFFFFC};
    arc_init(a, 4u<<20); arc_load_rom(a,(uint8_t*)prog,sizeof prog);

    /* CPU smoke test (boot ROM mirror at 0) */
    arc_frame(a); CHECK(a->ram[0]==0 && a->ram[1]==1 && a->ram[200]==200);

    /* MEMC: 32K pages, map ppn 3 -> logical page 5 (ppl 3), write through logical address */
    arc_reset(a); a->rom_high = 1;
    io_write(a, 0x03600000u | (0x7u<<17) | (3u<<2), 0);                       /* control: 32K pages */
    CHECK(a->pagesize == 3);
    { uint32_t ppn=3, lpn=5, ad = 0x03800000u | (0u<<8) | ((ppn>>4)&7) | (((ppn&0xF))<<3) | (lpn<<15);
      memc_map(a, ad); CHECK(a->lpn_ppn[5]==3 && a->ppn_lpn[3]==5);
      wr32(a, 5*32768+0x10, 0xCAFEF00D); CHECK(!a->abort);
      CHECK(*(uint32_t*)(a->ram + 3*32768 + 0x10) == 0xCAFEF00D);
      CHECK(rd32(a, 0x02000000u + 3*32768 + 0x10) == 0xCAFEF00D);            /* physical alias */
      a->abort=0; rd32(a, 6*32768); CHECK(a->abort==1); a->abort=0;          /* unmapped -> abort */
      a->mode=M_USR; wr32(a, 5*32768, 1); CHECK(a->abort==0);                  /* ppl 0: user r/w ok */
      a->ppn_ppl[3]=1; wr32(a, 5*32768, 1); CHECK(a->abort==1); a->abort=0;       /* ppl 1: user read-only */
      (void)rd32(a, 5*32768); CHECK(a->abort==0);
      a->ppn_ppl[3]=2; (void)rd32(a, 5*32768); CHECK(a->abort==1); a->abort=0; a->mode=M_SVC; }       /* ppl check */

    /* Timer 0 -> IRQ A bit 5 */
    arc_reset(a); ioc_write(a,0x03200040u,0x10); ioc_write(a,0x03200044u,0); ioc_write(a,0x03200048u,0);
    ioc_write(a,0x03200018u,0x20); hw_tick(a, 4*0x40); CHECK(a->irq==1);
    ioc_write(a,0x03200014u,0x20); CHECK(a->irq==0);

    /* Keyboard handshake and key event */
    arc_reset(a); kb_tx(a,0xFF); CHECK(ioc_read(a,0x03200004u)==0xFF);
    kb_tx(a,0xFE); CHECK(ioc_read(a,0x03200004u)==0xFE); kb_tx(a,0xFD); CHECK(ioc_read(a,0x03200004u)==0xFD);
    arc_key(a,0x3C,1); CHECK(a->kart_full && ioc_read(a,0x03200004u)==0xC3);
    kb_tx(a,0x3F); CHECK(ioc_read(a,0x03200004u)==0xCC);

    /* CMOS over I2C: write 0xAB to ram[0x40], read back */
    arc_reset(a);
    i2c_start(a); CHECK(i2c_wbyte(a,0xA0)); CHECK(i2c_wbyte(a,0x40)); CHECK(i2c_wbyte(a,0xAB)); i2c_stop(a);
    CHECK(a->cmos[0x40]==0xAB);
    i2c_start(a); CHECK(i2c_wbyte(a,0xA0)); CHECK(i2c_wbyte(a,0x40)); i2c_start(a); CHECK(i2c_wbyte(a,0xA1));
    CHECK(i2c_rbyte(a,0)==0xAB); i2c_stop(a);

    /* Floppy: ADFS D image (800K), read sector (track 2, side 0, sector 3), write sector, verify file */
    { FILE*f=fopen("/tmp/t.adf","wb"); int i; for(i=0;i<819200;i++) fputc((i/1024)&0xFF,f); fclose(f);
      CHECK(arc_disk_insert(a,0,"/tmp/t.adf")==0); CHECK(a->fdd[0].spt==5 && a->fdd[0].ssize==1024);
      a->latch_a = 0xFE|0x10; a->latch_set=1;                                  /* drive 0 selected, side 0 */
      fdc_write(a,3,2); fdc_write(a,0,0x10);                                    /* seek 2 */
      CHECK(a->head_track[0]==2 && a->fdc_track==2); (void)fdc_read(a,0);
      fdc_write(a,2,3); fdc_write(a,0,0x80);                                    /* read sector 3 */
      CHECK(a->fdc_drq==1 && (fdc_read(a,0)&3)==3);
      { int n=0, ok=1; uint32_t expect=((2*2*5)+3)&0xFF; while(a->fdc_drq){ uint32_t v=fdc_read(a,3); if(v!=expect) ok=0; n++; }
        CHECK(n==1024 && ok && a->fdc_irq==1); }
      (void)fdc_read(a,0); CHECK(a->fdc_irq==0);
      fdc_write(a,2,4); fdc_write(a,0,0xA0); { int i2; for(i2=0;i2<1024;i2++) fdc_write(a,3,0x5A); }
      CHECK(a->fdc_irq==1); arc_disk_eject(a,0);
      { FILE*g=fopen("/tmp/t.adf","rb"); int off=((2*2*5)+4)*1024; fseek(g,off,SEEK_SET); CHECK(fgetc(g)==0x5A); fseek(g,off+1024,SEEK_SET); CHECK(fgetc(g)==(((2*2*5)+5)&0xFF)); fclose(g); } }
    CHECK(arc_disk_insert(a,1,"/nonexistent.adf")<0);

    /* Sound DMA: channel 0 full-left, 48 us period, 16-byte buffer at 0x1000 */
    { int i, maxl = 0, maxr = 0, nz_tail = 0; arc_reset(a);
      vidc_write(a, (0x60u << 24) | 1); vidc_write(a, (0xC0u << 24) | 46);
      a->ram[0x1000] = 0xFE; a->ram[0x1008] = 0xFE;                          /* +8031 in frames 0 and 1 */
      memc_reg(a, 0x03600000u | (4u << 17) | ((0x1000u >> 4) << 2));         /* Sstart */
      memc_reg(a, 0x03600000u | (5u << 17) | ((0x1010u >> 4) << 2));         /* SendN  */
      memc_reg(a, 0x03600000u | (7u << 17) | (1u << 11) | (3u << 2));        /* control: sound DMA on */
      CHECK(a->s_running == 1 && a->snd_irq == 1 && (irqb_status(a) & 2));
      snd_gen(a); CHECK(a->snd_n == ARC_SND_FRAMES);
      for (i = 0; i < ARC_SND_FRAMES; i++) { int l = a->snd_out[i*2], r = a->snd_out[i*2+1]; if (l > maxl) maxl = l; if (r > maxr) maxr = r; if (i > 100 && (l || r)) nz_tail++; }
      CHECK(maxl > 20000 && maxr == 0);                 /* full-left, ~8031*3 */
      CHECK(a->s_running == 0 && nz_tail == 0);         /* buffer ran dry -> silence */
      a->snd_irq = 0; memc_reg(a, 0x03600000u | (4u << 17) | ((0x1000u >> 4) << 2)); memc_reg(a, 0x03600000u | (5u << 17) | ((0x1010u >> 4) << 2));
      CHECK(a->s_running == 1);                          /* a new buffer restarts playback */
      a->sdma = 0; snd_gen(a); CHECK(a->snd_out[10] == 0 && a->snd_out[11] == 0); }

    /* R15 rules: as Rn it is the bare address (ADR idiom, TEQP PC,#mode); as Rm it carries the PSR */
    { uint32_t prog2[4] = { 0xE28F0000u, 0xE33FF003u, 0xE1A0100Fu, 0xE1A00000u }; char rep[1024];
      arc_load_rom(a, (uint8_t *)prog2, sizeof prog2);
      step(a); CHECK(a->r[0] == 8);                                   /* ADD R0, PC, #0 -> pc+8 with no PSR bits */
      a->N = a->Z = a->C = a->V = 1; step(a);                           /* TEQP PC,#3: SVC mode, flags clear, IRQ/FIQ enabled */
      CHECK(a->mode == M_SVC && a->I == 0 && a->F == 0 && a->N == 0 && a->Z == 0 && a->C == 0 && a->V == 0);
      a->N = 1; a->I = 1; step(a);                                      /* MOV R1, PC -> includes PSR */
      CHECK((a->r[1] >> 31) == 1 && (a->r[1] & 3) == 3 && ((a->r[1] >> 27) & 1) == 1);
      arc_report(a, rep, sizeof rep); CHECK(strstr(rep, "PC ") != NULL && strstr(rep, "MEMC") != NULL);
      arc_report(a, rep, 16); }                                         /* tiny buffer must not overflow */

    /* ROM chip sets: the layout (lane order or contiguous quarters) is detected from vectors + ASCII text */
    { enum { N = 256 }; static uint8_t rom[N * 4], c[4][N], cq[4][N], o[N * 4];
      const uint8_t *p[4]; uint32_t seed = 12345; int i, k, t;
      for (i = 0; i < N * 4; i++) { seed = seed * 1664525u + 1013904223u; rom[i] = (uint8_t)(seed >> 24); }
      for (i = 0; i < 8; i++) rom[i * 4 + 3] = 0xEA;
      for (t = 0; t < 20; t++) memcpy(rom + 64 + t * 40, "the file is not found and the disc is in", 40);
      for (k = 0; k < 4; k++) for (i = 0; i < N; i++) { c[k][i] = rom[i * 4 + k]; cq[k][i] = rom[k * N + i]; }
      for (k = 0; k < 4; k++) p[k] = c[k];
      CHECK(arc_rom_interleave(p, N, o) == 0 && memcmp(o, rom, sizeof rom) == 0);                    /* plain lanes */
      for (k = 0; k < 4; k++) p[k] = c[3 - k];
      CHECK(arc_rom_interleave(p, N, o) != 0 && memcmp(o, rom, sizeof rom) == 0);                    /* reversed lanes */
      p[0] = c[2]; p[1] = c[0]; p[2] = c[3]; p[3] = c[1];
      CHECK(arc_rom_interleave(p, N, o) != 0 && memcmp(o, rom, sizeof rom) == 0);                    /* scrambled lanes */
      for (k = 0; k < 4; k++) p[k] = cq[k];
      CHECK(arc_rom_interleave(p, N, o) != 0 && memcmp(o, rom, sizeof rom) == 0);                    /* four contiguous quarters */
      p[0] = cq[1]; p[1] = cq[0]; p[2] = cq[3]; p[3] = cq[2];
      CHECK(arc_rom_interleave(p, N, o) != 0 && memcmp(o, rom, sizeof rom) == 0); }                  /* quarters, shuffled files */

    /* Save states: round trip, disk re-attach, wrong ROM, missing file */
    { uint32_t pc, r0; uint64_t cyc; uint8_t keep; arc_reset(a); arc_frame(a);
      CHECK(arc_disk_insert(a, 0, "/tmp/t.adf") == 0);
      pc = a->pc; r0 = a->r[0]; cyc = a->cycles; keep = a->ram[100];
      CHECK(arc_state_save(a, "/tmp/s.state") == 0);
      arc_frame(a); arc_frame(a); a->ram[100] ^= 0xFF; arc_disk_eject(a, 0);
      CHECK(a->pc != pc && a->cycles != cyc);
      CHECK(arc_state_load(a, "/tmp/s.state") == 0);
      CHECK(a->pc == pc && a->r[0] == r0 && a->cycles == cyc && a->ram[100] == keep);
      CHECK(a->fdd[0].inserted == 1 && a->rom != NULL && a->ram != NULL);
      arc_frame(a); CHECK(a->cycles > cyc);                                  /* still runs after load */
      a->rom[0] ^= 1; CHECK(arc_state_load(a, "/tmp/s.state") == -3); a->rom[0] ^= 1;
      CHECK(arc_state_load(a, "/tmp/does-not-exist.state") == -1);
      { FILE *g = fopen("/tmp/bad.state", "wb"); fputs("garbage", g); fclose(g); CHECK(arc_state_load(a, "/tmp/bad.state") == -2); }
      arc_disk_eject(a, 0); }

    printf("%d passed, %d failed\n", passes, fails); return fails != 0;
}
